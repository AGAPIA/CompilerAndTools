package com.agapia.graphicalinterface.model.common;

import java.util.List;
import java.util.Objects;

/**
 * a value object has no identity and is immutable
 * two value objects are equal if and only if all of their fields are also equal
 */
public abstract class ValueObject {

    protected abstract List<Object> attributesIncludedInEqualityCheck();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ValueObject that = (ValueObject) o;

        return attributesIncludedInEqualityCheck().equals(that.attributesIncludedInEqualityCheck());
    }

    @Override
    public int hashCode() {
        return Objects.hash(attributesIncludedInEqualityCheck());
    }
}
