package com.agapia.graphicalinterface.controller;

import com.agapia.graphicalinterface.model.module.port.Port;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.stream.Collectors;

public class PortRepresentation {
    @JsonProperty public List<VariableRepresentation> variables;

    public PortRepresentation() {
        //necessary for deserialization
    }

    public PortRepresentation(List<VariableRepresentation> variables) {
        this.variables = variables;
    }

    public Port toPort() {
        return new Port(
                variables.stream().map(VariableRepresentation::toVariable).collect(Collectors.toList())
        );
    }

    public static PortRepresentation fromPort(Port port) {
        PortRepresentation portRepresentation = new PortRepresentation();
        portRepresentation.variables = port.getVariables().stream().map(VariableRepresentation::fromVariable).collect(Collectors.toList());
        return portRepresentation;
    }
}
