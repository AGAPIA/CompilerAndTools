package com.agapia.graphicalinterface.model.module;

import com.agapia.graphicalinterface.model.common.ValueObject;

import java.util.List;

import static java.util.Collections.singletonList;

public class ModuleId extends ValueObject {
    private final int value;
    public static final ModuleId MAIN = new ModuleId(0);

    public ModuleId(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    @Override
    protected List<Object> attributesIncludedInEqualityCheck() {
        return singletonList(value);
    }
}
