package com.agapia.graphicalinterface.service.importservice;

import com.agapia.graphicalinterface.model.module.port.Port;
import com.agapia.graphicalinterface.model.module.port.Variable;
import com.agapia.graphicalinterface.model.module.port.VariableName;
import com.agapia.graphicalinterface.model.module.port.VariableType;

import java.util.ArrayList;
import java.util.List;

public class GetPortFromText {

    public static List<Port> get(String PortText)
    {
        List<Port> PortReturn = new ArrayList<>();
        if(PortText.contains("nil"))
        {
            return new ArrayList<>();
        }
        else {
            if (PortText.contains(";"))
            {
                String SplitVarsA[] = PortText.split(";");
                //Deal with them
                for(int a = 0 ; a < SplitVarsA.length; a++)
                {
                    String SplitVarsB[] = SplitVarsA[a].split(",");
                    List<Variable> ListaVariabile = new ArrayList<>();
                    for(int b = 0 ; b < SplitVarsB.length; b++)
                    {
                        String SplitVar[] = SplitVarsB[b].split(":");
                        Variable var = new Variable(new VariableName(SplitVar[0].trim()),new VariableType(SplitVar[1].trim()));
                        ListaVariabile.add(var);
                    }
                    PortReturn.add(new Port(ListaVariabile));
                }
            }
            else if(PortText.contains(","))
            {
                //Deal with it
                String SplitVarsB[] = PortText.split(",");
                List<Variable> ListaVariabile = new ArrayList<>();
                for(int b = 0 ; b < SplitVarsB.length; b++)
                {
                    String SplitVar[] = SplitVarsB[b].split(":");
                    Variable var = new Variable(new VariableName(SplitVar[0].trim()),new VariableType(SplitVar[1].trim()));
                    ListaVariabile.add(var);
                }
                PortReturn.add(new Port(ListaVariabile));
            }
            else
            {
                List<Variable> ListaVariabile = new ArrayList<>();
                String SplitVar[] = PortText.split(":");
                Variable var = new Variable(new VariableName(SplitVar[0].trim()),new VariableType(SplitVar[1].trim()));
                ListaVariabile.add(var);
                PortReturn.add(new Port(ListaVariabile));
            }
        }
        return PortReturn;
    }

    private GetPortFromText() {
    }
}
