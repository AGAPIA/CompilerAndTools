package com.agapia.graphicalinterface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphicalInterfaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphicalInterfaceApplication.class, args);
	}

}
