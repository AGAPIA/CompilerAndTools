package com.agapia.graphicalinterface.model.module;

import com.agapia.graphicalinterface.model.common.Entity;
import com.agapia.graphicalinterface.model.module.port.ModulePort;

public class Module extends Entity<ModuleId> {
    private String name;
    private ModuleType type;
    private ModuleId parentId;

    private String code;
    private ModulePort listenPort = ModulePort.empty();
    private ModulePort readPort = ModulePort.empty();
    private ModulePort speakPort = ModulePort.empty();
    private ModulePort writePort = ModulePort.empty();

    public Module(ModuleId id) {
        super(id);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ModuleType getType() {
        return type;
    }

    public void setType(ModuleType type) {
        this.type = type;
    }

    public ModuleId getParentId() {
        return parentId;
    }

    public void setParentId(ModuleId parentId) {
        this.parentId = parentId;
    }

    public ModulePort getListenPort() {
        return listenPort;
    }

    public void setListenPort(ModulePort listenPort) {
        this.listenPort = listenPort;
    }

    public ModulePort getReadPort() {
        return readPort;
    }

    public void setReadPort(ModulePort readPort) {
        this.readPort = readPort;
    }

    public ModulePort getSpeakPort() {
        return speakPort;
    }

    public void setSpeakPort(ModulePort speakPort) {
        this.speakPort = speakPort;
    }

    public ModulePort getWritePort() {
        return writePort;
    }

    public void setWritePort(ModulePort writePort) {
        this.writePort = writePort;
    }

    public String WriteModuleBody()
    {
        // module MAIN {listen nil}{read nil}
        // {
        //     READ # PRIMETEST
        // }{speak nil}{write nil}
        String ret = new String("module ");
        ret += this.name + " ";
        ret += "{listen "+listenPort.Print()+"}{read "+readPort.Print()+"}";
        ret += "\n{\n";
        ret += this.code;
        ret += "\n}{speak " + speakPort.Print() +"}{write " +writePort.Print()+"}";
        return ret;
    }


    private Module(Builder builder) {
        super(builder.id);
        this.name = builder.name;
        this.type = builder.type;
        this.parentId = builder.parentId;
        this.listenPort = builder.listenPort;
        this.readPort = builder.readPort;
        this.speakPort = builder.speakPort;
        this.writePort = builder.writePort;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static class Builder {
        private ModuleId id;
        private String name;
        private ModuleType type;
        private ModuleId parentId;

        private ModulePort listenPort = ModulePort.empty();
        private ModulePort readPort = ModulePort.empty();
        private ModulePort speakPort = ModulePort.empty();
        private ModulePort writePort = ModulePort.empty();

        public Builder id(ModuleId id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder type(ModuleType type) {
            this.type = type;
            return this;
        }

        public Builder parentId(ModuleId parentId) {
            this.parentId = parentId;
            return this;
        }

        public Builder listenPort(ModulePort listenPort) {
            this.listenPort = listenPort;
            return this;
        }

        public Builder readPort(ModulePort readPort) {
            this.readPort = readPort;
            return this;
        }

        public Builder speakPort(ModulePort speakPort) {
            this.speakPort = speakPort;
            return this;
        }

        public Builder writePort(ModulePort writePort) {
            this.writePort = writePort;
            return this;
        }

        public Module build() {
            return new Module(this);
        }
    }
}
