package com.agapia.graphicalinterface.model.module.port;

import com.agapia.graphicalinterface.model.common.ValueObject;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;

public class Port extends ValueObject {
    /*
    variabile separate prin ','
     */
    private final List<Variable> variables;

    public Port(List<Variable> variables) {
        this.variables = variables;
    }

    public List<Variable> getVariables() {
        return new ArrayList<>(variables);
    }

    @Override
    protected List<Object> attributesIncludedInEqualityCheck() {
        return singletonList(variables);
    }

    public String print() {
        if(variables.isEmpty()) return "";

        return variables.stream().map(Variable::print)
                .reduce("", (result, variable) -> result + ", " + variable)
                .substring(2);
    }

    @Override
    public String toString() {
        return "Port{" +
                "variables=" + variables +
                '}';
    }
}
