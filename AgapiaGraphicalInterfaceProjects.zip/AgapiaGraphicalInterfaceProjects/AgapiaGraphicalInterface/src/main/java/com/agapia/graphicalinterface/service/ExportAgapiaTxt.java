package com.agapia.graphicalinterface.service;

import com.agapia.graphicalinterface.model.module.Module;
import com.agapia.graphicalinterface.model.module.ModuleId;
import com.agapia.graphicalinterface.model.module.ModuleType;
import com.agapia.graphicalinterface.model.module.port.ConnectionType;
import com.agapia.graphicalinterface.service.export.WriteModulesHelper;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ExportAgapiaTxt {

    public byte[] export(List<Module> modules) {
        Queue<Module> calculateModulesQueue = new ArrayDeque<>();

        Module mainModule = modules.stream().filter(m -> m.getId().equals(ModuleId.MAIN)).findFirst().orElseThrow(() -> new NoSuchElementException("MAIN module not found"));
        calculateModulesQueue.add(mainModule);

        WriteModulesHelper writeModulesHelper = new WriteModulesHelper();

        while (!calculateModulesQueue.isEmpty()) {
            Module module = calculateModulesQueue.remove();
            module.setCode(WriteModulesHelper.writeWithIndentation("", 1) + calculateChildrenModules(module, calculateModulesQueue, modules, 1));
            writeModulesHelper.addModuleToWrite(module);
        }

        return writeModulesHelper.writeAll().getBytes();
    }

    private static String calculateChildrenModules(Module module, Queue<Module> calculateModulesQueue, List<Module> modules, int nested) {
        List<Module> childrenModules = modules.stream().filter(m -> m.getParentId() != null && m.getParentId().equals(module.getId()))
                .collect(Collectors.toList());
        if(childrenModules.isEmpty()) {
            module.setCode("");
            return "";
        }
        else {
            List<Module> firstModuleCandidates = childrenModules.stream()
                    .filter(m -> m.getListenPort().getConnectsTo() == null && m.getReadPort().getConnectsTo() == null)
                    .collect(Collectors.toList());
            if(firstModuleCandidates.isEmpty()) {
                throw new IllegalStateException("Cyclical dependency found in module " + module.getName());
            }
            if(firstModuleCandidates.size() > 1) {
                throw new IllegalStateException("Unconnected modules found in module " + module.getName());
            }

            return calculateCodeStartingWith(firstModuleCandidates.get(0), calculateModulesQueue, modules, nested);
        }
    }

    private static String calculateCodeStartingWith(Module startModule, Queue<Module> calculateModulesQueue, List<Module> modules, int nested) {
        String code = "";
        if(startModule.getType() == ModuleType.USER_DEFINED) {
            code = code + startModule.getName();
            calculateModulesQueue.add(startModule);
        }
        else {
            code = code + WriteModulesHelper.writeByModuleType(calculateChildrenModules(startModule, calculateModulesQueue, modules, nested + 1), startModule.getType());
        }

        WriteModulesHelper.Pair<Module, ConnectionType> next = nextModuleAndConnectionString(startModule, modules);

        while (next != null) {
            if(next.get1().getType() == ModuleType.USER_DEFINED) {
                code = WriteModulesHelper.appendWithIndentation(new WriteModulesHelper.Pair<>(next.get1().getName(), next.get2()), code, nested);
                calculateModulesQueue.add(next.get1());
            }
            else {
                code = WriteModulesHelper.appendWithIndentation(new WriteModulesHelper.Pair<>(calculateCodeStartingWith(next.get1(), calculateModulesQueue, modules, nested + 1),
                        next.get2()), code, nested);
            }

            next = nextModuleAndConnectionString(
                    next.get1(),
                    modules
            );
        }

        return code;
    }

    private static WriteModulesHelper.Pair<Module, ConnectionType> nextModuleAndConnectionString(Module startModule, List<Module> modules) {
        if(startModule.getSpeakPort().getConnectsTo() != null && startModule.getWritePort().getConnectsTo() != null) {
            if(!startModule.getSpeakPort().getConnectsTo().equals(startModule.getWritePort().getConnectsTo())) {
                throw new IllegalStateException("Unable to determine operation order for module " + startModule.getName());
            }
            return new WriteModulesHelper.Pair<>(findModuleById(startModule.getSpeakPort().getConnectsTo(), modules), ConnectionType.D);
        }
        else if(startModule.getSpeakPort().getConnectsTo() != null) {
            return new WriteModulesHelper.Pair<>(findModuleById(startModule.getSpeakPort().getConnectsTo(), modules), ConnectionType.H);
        }
        else if(startModule.getWritePort().getConnectsTo() != null) {
            return new WriteModulesHelper.Pair<>(findModuleById(startModule.getWritePort().getConnectsTo(), modules), ConnectionType.V);
        }
        else {
            return null;
        }
    }

    private static Module findModuleById(ModuleId moduleId, List<Module> modules) {
        return modules.stream().filter(m -> m.getId().equals(moduleId)).findFirst().orElseThrow(() -> new NoSuchElementException("Module not found. Id: " + moduleId.getValue()));
    }
}
