package com.agapia.graphicalinterface.model.module.port;

public enum ConnectionType {
    H,V,D
}
