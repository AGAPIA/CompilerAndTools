package com.agapia.graphicalinterface.controller;

import com.agapia.graphicalinterface.model.module.Module;
import com.agapia.graphicalinterface.model.module.ModuleId;
import com.agapia.graphicalinterface.model.module.ModuleType;
import com.fasterxml.jackson.annotation.JsonProperty;

import static java.util.Objects.isNull;

public class ModuleRepresentation {
    @JsonProperty public Integer id;
    @JsonProperty public String name;
    @JsonProperty public String type;
    @JsonProperty public Integer parentId;
    @JsonProperty public ModulePortRepresentation listenPort;
    @JsonProperty public ModulePortRepresentation readPort;
    @JsonProperty public ModulePortRepresentation speakPort;
    @JsonProperty public ModulePortRepresentation writePort;

    public Module toModule() {
        return new Module.Builder()
                .id(new ModuleId(id))
                .name(name)
                .type(ModuleType.valueOf(type))
                .parentId(isNull(parentId) ? null : new ModuleId(parentId))
                .listenPort(listenPort.toModulePort())
                .readPort(readPort.toModulePort())
                .speakPort(speakPort.toModulePort())
                .writePort(writePort.toModulePort())
                .build();
    }

    public static ModuleRepresentation fromModule(Module module) {
        ModuleRepresentation moduleRepresentation = new ModuleRepresentation();
        moduleRepresentation.id = module.getId().getValue();
        moduleRepresentation.name = module.getName();
        moduleRepresentation.type = module.getType().name();
        moduleRepresentation.parentId = isNull(module.getParentId()) ? null : module.getParentId().getValue();
        moduleRepresentation.listenPort = ModulePortRepresentation.fromModulePort(module.getListenPort());
        moduleRepresentation.readPort = ModulePortRepresentation.fromModulePort(module.getReadPort());
        moduleRepresentation.speakPort = ModulePortRepresentation.fromModulePort(module.getSpeakPort());
        moduleRepresentation.writePort = ModulePortRepresentation.fromModulePort(module.getWritePort());
        return moduleRepresentation;
    }
}
