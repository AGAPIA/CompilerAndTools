package com.agapia.graphicalinterface.model.module;

public enum ModuleType {
    USER_DEFINED, PARENTHESIS, FOREACH, FOR
}
