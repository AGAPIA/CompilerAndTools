package com.agapia.graphicalinterface.model.module.port;

import com.agapia.graphicalinterface.model.common.ValueObject;

import java.util.List;

import static java.util.Collections.singletonList;

public class VariableType extends ValueObject {
    private final String value;

    public VariableType(String value) {
        this.value = value;
    }
    public VariableType(){this.value = "nil";}
    public String getValue() {
        return value;
    }

    @Override
    protected List<Object> attributesIncludedInEqualityCheck() {
        return singletonList(value);
    }
}
