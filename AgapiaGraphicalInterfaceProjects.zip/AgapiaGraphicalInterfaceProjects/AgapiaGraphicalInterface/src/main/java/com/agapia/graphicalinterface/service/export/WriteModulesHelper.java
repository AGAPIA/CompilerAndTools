package com.agapia.graphicalinterface.service.export;

import com.agapia.graphicalinterface.model.module.Module;
import com.agapia.graphicalinterface.model.module.ModuleType;
import com.agapia.graphicalinterface.model.module.port.ConnectionType;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class WriteModulesHelper {
    public static String INDENTATION = "  ";
    public static String NEWLINE = "\n";

    private final List<Module> modulesToWrite = new ArrayList<>();

    public String writeAll() {
        StringBuilder stringBuffer = new StringBuilder(modulesToWrite.get(0).WriteModuleBody());

        for(int i = 1; i< modulesToWrite.size(); i++) {
            stringBuffer.append(NEWLINE).append(NEWLINE).append(modulesToWrite.get(i).WriteModuleBody());
        }

//        System.out.println(stringBuffer.toString());
        return stringBuffer.toString();
    }

    public void addModuleToWrite(Module module) {
        this.modulesToWrite.add(module);
    }

    public static String writeWithIndentation(String code, int indentation) {
        return getIndentation(indentation) + code;
    }

    public static String writeByModuleType(String nestedCode, ModuleType moduleType) {
        if(moduleType == ModuleType.USER_DEFINED) {
            throw new UnsupportedOperationException("Method only appends nested module types");
        }
        if(moduleType == ModuleType.PARENTHESIS) {
            return writeParenthesisWithIndentation(nestedCode);
        }
        if(moduleType == ModuleType.FOR) {
            //TODO
            throw new UnsupportedOperationException();
        }

        if(moduleType == ModuleType.FOREACH) {
            return writeForeachWithIndentation(nestedCode);
        }
        throw new UnsupportedOperationException("Connection type not implemented. Probably a bug");
    }

    private static String writeParenthesisWithIndentation(String nestedCode) {
        return "(" + nestedCode + ")";
    }

    private static String writeForeachWithIndentation(String nestedCode) {
        return "foreach_s( ) {" + nestedCode + "}";
    }

    public static String appendWithIndentation(Pair<String, ConnectionType> pair, String code, int indentation) {
        if(pair.member2 == ConnectionType.H) {
            return code + " # " + pair.member1;
        }
        if(pair.member2 == ConnectionType.V) {
            return code + NEWLINE + getIndentation(indentation) + "%" + NEWLINE + getIndentation(indentation) + pair.member1;
        }
        if(pair.member2 == ConnectionType.D) {
            return code + " $ " + pair.member1;
        }
        throw new UnsupportedOperationException("Connection type not implemented. Probably a bug");
    }

    public static String appendByModuleTypeWithIndentation(Pair<String, ConnectionType> pair, ModuleType moduleType, String code, int indentation) {
        if(moduleType == ModuleType.USER_DEFINED) {
            throw new UnsupportedOperationException("Method only appends nested module types");
        }
        if(moduleType == ModuleType.PARENTHESIS) {
            return appendParenthesisWithIndentation(pair, code, indentation);
        }
        if(moduleType == ModuleType.FOR) {
            //TODO
            throw new UnsupportedOperationException();
        }

        if(moduleType == ModuleType.FOREACH) {
            //TODO
            throw new UnsupportedOperationException();
        }
        throw new UnsupportedOperationException("Connection type not implemented. Probably a bug");
    }

    private static String appendParenthesisWithIndentation(Pair<String, ConnectionType> pair, String code, int indentation) {
        if(pair.member2 == ConnectionType.H) {
            return code + " # " + "(" + pair.member1 + ")";
        }
        if(pair.member2 == ConnectionType.V) {
            return code +
                    NEWLINE + getIndentation(indentation) + "%" +
                    NEWLINE + getIndentation(indentation) + "(" + pair.member1 + ")";
        }
        if(pair.member2 == ConnectionType.D) {
            return code + " $ " + "(" + pair.member1 + ")";
        }
        throw new UnsupportedOperationException("Connection type not implemented. Probably a bug");
    }

    private static String getIndentation(int indentation) {
        StringBuilder stringBuffer = new StringBuilder();
        IntStream.range(0, indentation).forEach((i) -> stringBuffer.append(INDENTATION));
        return stringBuffer.toString();
    }


    public static class Pair<T,R> {
        private T member1;
        private R member2;

        public Pair(T member1, R member2) {
            this.member1 = member1;
            this.member2 = member2;
        }

        public T get1() {
            return member1;
        }

        public R get2() {
            return member2;
        }
    }
}
