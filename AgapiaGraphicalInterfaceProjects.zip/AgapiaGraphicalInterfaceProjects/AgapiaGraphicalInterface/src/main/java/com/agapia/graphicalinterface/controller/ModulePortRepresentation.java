package com.agapia.graphicalinterface.controller;

import com.agapia.graphicalinterface.model.module.ModuleId;
import com.agapia.graphicalinterface.model.module.port.ModulePort;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Objects.isNull;

public class ModulePortRepresentation {
    @JsonProperty public Integer connectsTo;
    @JsonProperty public List<PortRepresentation> ports;

    public ModulePortRepresentation() {
        ports = new ArrayList<>();
    }

    public ModulePort toModulePort() {
        return new ModulePort(
                isNull(connectsTo) ? null : new ModuleId(connectsTo),
                ports.stream().map(PortRepresentation::toPort).collect(Collectors.toList())
        );
    }

    public static ModulePortRepresentation fromModulePort(ModulePort modulePort) {
        ModulePortRepresentation modulePortRepresentation = new ModulePortRepresentation();
        modulePortRepresentation.connectsTo = isNull(modulePort.getConnectsTo()) ? null : modulePort.getConnectsTo().getValue();
        modulePortRepresentation.ports = modulePort.getPorts().stream().map(PortRepresentation::fromPort).collect(Collectors.toList());
        return modulePortRepresentation;
    }
}
