package com.agapia.graphicalinterface.service;

import com.agapia.graphicalinterface.model.module.Module;
import com.agapia.graphicalinterface.model.module.ModuleId;
import com.agapia.graphicalinterface.model.module.ModuleType;
import com.agapia.graphicalinterface.model.module.port.*;
import com.agapia.graphicalinterface.service.export.WriteModulesHelper;
import com.agapia.graphicalinterface.service.importservice.GetPortFromText;
import com.agapia.graphicalinterface.service.importservice.IdGenerator;
import org.springframework.stereotype.Service;

import javax.swing.text.html.StyleSheet;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ImportAgapiaTxt {

    void parseCode(Module ThisModule,List<Module> Modules, IdGenerator idGenerator)
    {
        //parseCode method
        //iterates through the code of the Modules
        //to establish connections
        //parent id
        //solve paranthesis

        String code = ThisModule.getCode();
        ModuleId ParentId = ThisModule.getId();
        // countparanthesis iterates the paranthesis ordinally
        int countparanthesis = 0; // for example : A(BC)D(EF) => BC = 0, EF = 1
        while(code.contains(")") && code.contains("("))
        {
            //nested loops iterates the paranthesis recursively
            //to establish the big paranthesis
            int nestedloop = -1;
            int indexofthefirstOPENP = code.indexOf("(");
            nestedloop++;
            int charindex = indexofthefirstOPENP;
            int indexoftheclosingP = 0;// indexes of the ")" within the code
            while(nestedloop > -1)//Calculating the level of the nested loop
            {
                charindex++;//while iterating through the code characters
                //System.out.println(code.charAt(charindex));
                if(code.charAt(charindex) == '(')
                {
                    nestedloop++;
                }
                else if(code.charAt(charindex) == ')')
                {
                    indexoftheclosingP = charindex;//only saving the index of the big paranthesis
                    nestedloop--;
                }
            }
            //System.out.println("Am trecut de paranteze");
            //Creating the Paranthesis Module
            String NumeParanteza = "" + ParentId.getValue() + "P" + countparanthesis;//Naming scheme of the Paranthesis modules : 0P0,0P1...1P0,1P1.etc
            Module Paranthesis = new Module(new ModuleId(idGenerator.getNextId(NumeParanteza)));
            Paranthesis.setName(NumeParanteza);
            Paranthesis.setType(ModuleType.PARENTHESIS);
            Paranthesis.setParentId(ThisModule.getId());
            System.out.println(code.substring(indexofthefirstOPENP+1,indexoftheclosingP));
            Paranthesis.setCode(code.substring(indexofthefirstOPENP+1,indexoftheclosingP));
            //Replace code inside parathesis with Paranthesis Name
            parseCode(Paranthesis,Modules, idGenerator);
            code = code.replace("("+Paranthesis.getCode()+")",Paranthesis.getName());//A(BC)D A0P0D
            //0P0%E0P1
            Modules.add(Paranthesis);
            countparanthesis++;
        }
        List<WriteModulesHelper.Pair<Integer,String>> ListIndexModuleName = new ArrayList<>();
        for (Module module : Modules)
        {
            //System.out.println(module.getName());
            String Name = module.getName();

            int cindexofname = code.indexOf(Name);
            while(cindexofname != -1)
            {
                //System.out.println("WhileName");

                //System.out.println(cindexofname);
                //System.out.println(Name);
                //System.out.println(code.charAt(cindexofname + Name.length()));
                if((cindexofname + Name.length()) < code.length() && ((code.charAt(cindexofname + Name.length()) >= 'a' && code.charAt(cindexofname + Name.length()) <= 'z') || (code.charAt(cindexofname + Name.length()) >= 'A' && code.charAt(cindexofname + Name.length()) <= 'Z') || code.charAt(cindexofname + Name.length()) == '_'))
                {//All legal characters for the Module name should be included in this section
                    //System.out.println("In if");
                    cindexofname = code.indexOf(Name,cindexofname);

                }
                else
                {
                    //System.out.println("else");
                    ListIndexModuleName.add(new WriteModulesHelper.Pair<>(cindexofname,Name));
                    break;
                }
            }
        }
//        for(String Name : ModulesNames)
//        {
//            //System.out.println(Name);
//
//        }
        //READALL #READTOUT # READ
        ListIndexModuleName.sort(new Comparator<WriteModulesHelper.Pair<Integer,String>>() {
            @Override public int compare(WriteModulesHelper.Pair<Integer,String> p1, WriteModulesHelper.Pair<Integer,String> p2)
            {
                return p1.get1() - p2.get1();
            }});
        ListIndexModuleName = ListIndexModuleName.stream().filter(integerStringPair -> integerStringPair.get1() != -1).collect(Collectors.toList());
        //
        //ListIndexModuleName sorted asc and filtered out the Modules which are not included in this part of the code
        //System.out.println("past sorting");
        for(int i = 0 ; i < ListIndexModuleName.stream().count() -1 ; i++)
        {
            String substring = code.substring(ListIndexModuleName.get(i).get1(),ListIndexModuleName.get(i+1).get1()+ListIndexModuleName.get(i+1).get2().length());
            if(substring.contains("#"))
            {
                //Connect Listen[i+1] -> Speak[i]
                for(int j = 0 ; j < Modules.stream().count(); j++)
                {
                    if(Modules.get(j).getName().equals(ListIndexModuleName.get(i).get2()))
                    {
                        for(int k = 0 ; k < Modules.stream().count(); k++)
                        {
                            if(Modules.get(k).getName().equals(ListIndexModuleName.get(i+1).get2()))
                            {
                                //j = sending module
                                //k = receiving module
                                //Modules.get(k).getId(),Modules.get(j).getSpeakPort().getPorts()
                                Modules.get(j).setSpeakPort(new ModulePort(Modules.get(k).getId(),Modules.get(j).getSpeakPort().getPorts()));
                                //Modules.get(j).getId(),Modules.get(k).getListenPort().getPorts())
                                Modules.get(k).setListenPort(new ModulePort(Modules.get(j).getId(),Modules.get(j).getSpeakPort().getPorts()));
                                //SetIdParent
                                Modules.get(j).setParentId(ParentId);
                                Modules.get(k).setParentId(ParentId);
                            //break?
                            }
                        }
                        //break?
                    }
                }
            }
            else if(substring.contains("%"))
            {
                //Connect Read[i+1] -> write[i]
                for(int j = 0 ; j < Modules.stream().count(); j++)
                {
                    if(Modules.get(j).getName() == ListIndexModuleName.get(i).get2())
                    {
                        for(int k = 0 ; k < Modules.stream().count(); k++)
                        {
                            if(Modules.get(k).getName() == ListIndexModuleName.get(i+1).get2())
                            {
                                //j = sending module
                                //k = receiving module
                                //Modules.get(k).getId(),Modules.get(j).getSpeakPort().getPorts()
                                Modules.get(j).setWritePort(new ModulePort(Modules.get(k).getId(),Modules.get(j).getWritePort().getPorts()));
                                //Modules.get(j).getId(),Modules.get(k).getListenPort().getPorts())
                                Modules.get(k).setReadPort(new ModulePort(Modules.get(j).getId(),Modules.get(k).getReadPort().getPorts()));
                                //SetIdParent
                                Modules.get(j).setParentId(ParentId);
                                Modules.get(k).setParentId(ParentId);
                                //break?
                            }
                        }
                        //break?
                    }
                }
            }
            else if(substring.contains("$"))
            {
                //Connect Read[i+1] -> write[i]
                //Connect Listen[i+1] -> Speak[i]
                for(int j = 0 ; j < Modules.stream().count(); j++)
                {
                    if(Modules.get(j).getName().equals(ListIndexModuleName.get(i).get2()))
                    {
                        for(int k = 0 ; k < Modules.stream().count(); k++)
                        {
                            if(Modules.get(k).getName().equals(ListIndexModuleName.get(i+1).get2()))
                            {
                                //j = sending module
                                //k = recieving module
                                //Modules.get(k).getId(),Modules.get(j).getReadPort().getPorts()
                                Modules.get(j).setWritePort(new ModulePort(Modules.get(k).getId(),Modules.get(j).getWritePort().getPorts()));
                                //Modules.get(j).getId(),Modules.get(k).getWritePort().getPorts())
                                Modules.get(k).setReadPort(new ModulePort(Modules.get(j).getId(),Modules.get(k).getReadPort().getPorts()));
                                //Modules.get(k).getId(),Modules.get(j).getSpeakPort().getPorts()
                                Modules.get(j).setSpeakPort(new ModulePort(Modules.get(k).getId(),Modules.get(j).getSpeakPort().getPorts()));
                                //Modules.get(j).getId(),Modules.get(k).getListenPort().getPorts())
                                Modules.get(k).setListenPort(new ModulePort(Modules.get(j).getId(),Modules.get(k).getListenPort().getPorts()));
                                //SetIdParent
                                Modules.get(j).setParentId(ParentId);
                                Modules.get(k).setParentId(ParentId);
                                //break?
                            }
                        }
                        //break?
                    }
                }
            }

        }


    }

    public List<Module> importTxt(byte[] agapiaTxtFile) {
        //From agapia text file to List of Modules


        //IdGenerator keeps every id of the modules used with their respective name
        IdGenerator idGenerator = new IdGenerator();
        //idGenerator.getNextId("ModuleName");//New module name
        //idGenerator.idsbyName("ModuleName");//Get ids of the module by name

        String TextFile = new String(agapiaTxtFile);
        List<Module> moduleArrayList = new ArrayList<>();


        String ModuleArray[] = TextFile.split("module ");
        //Getting MAIN
        for(int i = 1 ; i < ModuleArray.length ;i++)
        {

            int j = 0;
            String modulename = new String();

                while(ModuleArray[i].charAt(j) != '{')
                {
                    modulename += ModuleArray[i].charAt(j++);
                }
                modulename = modulename.trim();
                if(!modulename.isEmpty())
                {
                    Module newmodule = new Module(new ModuleId(idGenerator.getNextId(modulename)));
                    newmodule.setName(modulename);
                    newmodule.setType(ModuleType.USER_DEFINED);

                    int listenportpos = ModuleArray[i].indexOf("listen",j);
                    listenportpos += "listen".length();
                    String PortListen = new String();
                    while(ModuleArray[i].charAt(listenportpos) != '}')
                    {
                        PortListen += ModuleArray[i].charAt(listenportpos++);
                    }
                    PortListen = PortListen.trim();
                    //SomehowSetPort
                    newmodule.setListenPort(new ModulePort(null, GetPortFromText.get(PortListen)));


                    int readportpos = ModuleArray[i].indexOf("read",listenportpos);
                    readportpos += "read".length();
                    String PortRead = new String();
                    while(ModuleArray[i].charAt(readportpos) != '}')
                    {
                        PortRead += ModuleArray[i].charAt(readportpos++);
                    }
                    PortRead = PortRead.trim();
                    //SomehowSetPort
                    newmodule.setReadPort(new ModulePort(null,GetPortFromText.get(PortRead)));


                    j = readportpos + 1;
                    int speakportpos = ModuleArray[i].indexOf("}{speak",j);


                    //Set the code of the module
                    newmodule.setCode(ModuleArray[i].substring(j,speakportpos));

                    speakportpos += "}{speak".length();
                    String PortSpeak = new String();
                    while(ModuleArray[i].charAt(speakportpos) != '}')
                    {
                        PortSpeak += ModuleArray[i].charAt(speakportpos++);
                    }
                    PortSpeak = PortSpeak.trim();
                    //SomehowSetPort
                    newmodule.setSpeakPort(new ModulePort(null,GetPortFromText.get(PortSpeak)));

                    int writeportpos = ModuleArray[i].indexOf("{write",speakportpos);
                    writeportpos += "{write".length();
                    String PortWrite = new String();
                    while(ModuleArray[i].charAt(writeportpos) != '}')
                    {
                        PortWrite += ModuleArray[i].charAt(writeportpos++);
                    }
                    //SomehowSetPort
                    newmodule.setWritePort(new ModulePort(null,GetPortFromText.get(PortWrite)));
                    moduleArrayList.add(newmodule);
                }
        }
//        for()
//        {
//            for()
//            {
//                if(moduleCodeContainsAgapiaModule)
//                {
//                    parse
//                }
//            }
//        }

//        List<Module> modulesToParseCode = new ArrayList<>(moduleArrayList);
//        modulesToParseCode.stream().filter(m -> moduleCodeContainsAgapiaModule(m, new ArrayList<>(new ArrayList<>(moduleArrayList)))).collect(Collectors.toList());
//
//        modulesToParseCode.forEach(module -> parseCode(module,moduleArrayList,idGenerator));
        parseCode(moduleArrayList.get(0),moduleArrayList,idGenerator);
        return moduleArrayList;
    }

    private boolean moduleCodeContainsAgapiaModule(Module module, List<Module> modules) {
        for (Module mod : modules)
        {
            if(module.getCode().contains(mod.getName()))
            {
                return true;
            }
        }
        return false;
    }
}
