package com.agapia.graphicalinterface.controller;

import com.agapia.graphicalinterface.model.module.Module;
import com.agapia.graphicalinterface.model.module.ModuleId;
import com.agapia.graphicalinterface.model.module.ModuleType;
import com.agapia.graphicalinterface.model.module.port.*;
import com.agapia.graphicalinterface.service.ExportAgapiaTxt;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.Objects.requireNonNull;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/agapia")
public class ExportController {

    private final ExportAgapiaTxt exportAgapiaTxt;

    public ExportController(ExportAgapiaTxt exportAgapiaTxt) {
        this.exportAgapiaTxt = requireNonNull(exportAgapiaTxt);
    }

    @PostMapping("/export")
    public ResponseEntity<Resource> exportAgapiaTxtForSchema(@RequestBody List<ModuleRepresentation> modules) {
        byte[] txtContent = exportAgapiaTxt.export(
                modules.stream().map(ModuleRepresentation::toModule).collect(Collectors.toList())
        );
        
        ByteArrayResource resource = new ByteArrayResource(txtContent);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "agapia.txt")
                .body(resource);
    }

    @GetMapping("/testModule")
    public List<ModuleRepresentation> test() {
        //asa ceva ar trebui sa primesc eu la import
        ModulePort listenPort = new ModulePort(null, emptyList());
        ModulePort readPort = new ModulePort(null,
                singletonList(new Port(singletonList(
                        new Variable(new VariableName("m"), new VariableType("int"))))
                )
        );
        ModulePort speakPort = new ModulePort(null,
                singletonList(new Port(asList(
                        new Variable(new VariableName("n"), new VariableType("int")),
                        new Variable(new VariableName("b"), new VariableType("boolean"))))
                )
        );
        ModulePort writePort = new ModulePort(null,
                asList(new Port(singletonList(
                        new Variable(new VariableName("i"), new VariableType("int")))),
                        new Port(asList(
                                new Variable(new VariableName("a"), new VariableType("boolean")),
                                new Variable(new VariableName("x"), new VariableType("float"))))
                )
        );

        Module expected = new Module.Builder()
                .id(new ModuleId(1))
                .name("EXAMPLE")
                .type(ModuleType.USER_DEFINED)
                .parentId(new ModuleId(0))
                .listenPort(listenPort)
                .readPort(readPort)
                .speakPort(speakPort)
                .writePort(writePort)
                .build();
        return asList(ModuleRepresentation.fromModule(expected));
    }
}
