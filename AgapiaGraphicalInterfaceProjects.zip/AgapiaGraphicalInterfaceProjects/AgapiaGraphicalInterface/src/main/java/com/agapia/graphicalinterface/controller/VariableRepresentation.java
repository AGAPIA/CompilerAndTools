package com.agapia.graphicalinterface.controller;

import com.agapia.graphicalinterface.model.module.port.Variable;
import com.agapia.graphicalinterface.model.module.port.VariableName;
import com.agapia.graphicalinterface.model.module.port.VariableType;
import com.fasterxml.jackson.annotation.JsonProperty;

public class VariableRepresentation {
    @JsonProperty public String name;
    @JsonProperty public String type;

    public VariableRepresentation() {
        //necessary for deserialization
    }

    public VariableRepresentation(String name, String type) {
        this.name = name;
        this.type = type;
    }

    public Variable toVariable() {
        return new Variable(new VariableName(name), new VariableType(type));
    }

    public static VariableRepresentation fromVariable(Variable variable) {
        VariableRepresentation variableRepresentation = new VariableRepresentation();
        variableRepresentation.name = variable.getName().getValue();
        variableRepresentation.type = variable.getType().getValue();
        return variableRepresentation;
    }
}
