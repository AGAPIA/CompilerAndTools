package com.agapia.graphicalinterface.controller;

import com.agapia.graphicalinterface.service.ImportAgapiaTxt;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Objects.requireNonNull;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/agapia")
public class ImportController {
    private final ImportAgapiaTxt importAgapiaTxt;

    public ImportController(ImportAgapiaTxt importAgapiaTxt) {
        this.importAgapiaTxt = requireNonNull(importAgapiaTxt);
    }

    @PostMapping(value = "/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<List<ModuleRepresentation>> importAgapiaTxt(@RequestParam("file") MultipartFile multipartFile) {
        try {
            return ResponseEntity.ok(importAgapiaTxt.importTxt(multipartFile.getBytes()).stream()
                    .map(ModuleRepresentation::fromModule).collect(Collectors.toList()));
        }
        catch (IOException e) {
            //aici ar putea fi o gramda de exceptii de prins si mesaje speciale pt fiecare
            //in functie de ce gasim in fisier
            e.printStackTrace();
            return ResponseEntity.status(BAD_REQUEST).build();
        }
    }
}
