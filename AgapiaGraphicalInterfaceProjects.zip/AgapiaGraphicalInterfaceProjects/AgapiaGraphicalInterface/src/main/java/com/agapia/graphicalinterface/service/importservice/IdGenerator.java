package com.agapia.graphicalinterface.service.importservice;

import com.agapia.graphicalinterface.service.export.WriteModulesHelper;

import java.util.ArrayList;
import java.util.List;

public class IdGenerator {
    private int nextId = 1;
    private List<WriteModulesHelper.Pair<String,Integer>> pairList = new ArrayList<>();

    public int getNextId(String ModuleName) {
        if(ModuleName.equals("MAIN"))
        {
            pairList.add(new WriteModulesHelper.Pair<>(ModuleName,0));
            return 0;
        }
        else
        {
            pairList.add(new WriteModulesHelper.Pair<>(ModuleName,nextId));
            return nextId++;
        }
    }
    public List<Integer> idsbyName(String ModuleName)
    {
        List<Integer> ret = new ArrayList<>();
        for(int i = 0 ; i < pairList.stream().count(); i++)
        {
            if(pairList.get(i).get1() == ModuleName)
            {
                ret.add(pairList.get(i).get2());
            }
        }
        return ret;
    }
}
