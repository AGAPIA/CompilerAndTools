package com.agapia.graphicalinterface.model.module.port;

import com.agapia.graphicalinterface.model.common.ValueObject;
import com.agapia.graphicalinterface.model.module.ModuleId;

import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

public class ModulePort extends ValueObject {
    private ModuleId connectsTo;
    /*
    lista de port-uri (secvente de variabile separate prin ';')
    {int n; int x, int y} se traduce in lista [ {int n}, {[int x, int y]} ]
     */
    private final List<Port> ports;


    public ModulePort(ModuleId connectsTo, List<Port> ports) {
        this.connectsTo = connectsTo;
        this.ports = ports;
    }

    public static ModulePort nilPort() {
        return new ModulePort(null, new ArrayList<>());
    }

    public ModuleId getConnectsTo() {
        return connectsTo;
    }

    public void setConnectsTo(ModuleId connectsTo) {
        this.connectsTo = connectsTo;
    }

    public List<Port> getPorts() {
        return new ArrayList<>(ports);
    }

    public static ModulePort empty() {
        return new ModulePort(null, new ArrayList<>());
    }

    @Override
    protected List<Object> attributesIncludedInEqualityCheck() {
        return asList(connectsTo, ports);
    }

    public String Print() {

        if(ports.isEmpty())
        {
            return "nil";
        }

//        String ret = new String();
//
//        for(int i = 0 ; i < ports.size(); i++) {
//            //concat nu modifica string-ul pe care se apeleaza, ci intoarce unul nou
//            ret = ret.concat(ports.get(i).print() + ";");
//        }
//
//        ret.substring(0,ret.length() -1);
//        return ret;

        return ports.stream()
                .map(Port::print)
                .reduce("", (result, port) -> result + "; " + port)
                .substring(2);
    }
}
