package com.agapia.graphicalinterface.model.common;

import java.util.Objects;

/**
 * an entity is mutable and it's identity is based on an id
 * two entities are equal if and only if their ids are equal
 */
public class Entity<I> {
    private final I id;

    public Entity(I id) {
        this.id = id;
    }

    public I getId() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Entity<?> entity = (Entity<?>) o;
        return Objects.equals(id, entity.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
