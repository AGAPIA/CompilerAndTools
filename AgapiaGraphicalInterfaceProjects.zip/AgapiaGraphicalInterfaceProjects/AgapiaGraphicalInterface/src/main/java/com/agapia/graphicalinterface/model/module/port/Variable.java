package com.agapia.graphicalinterface.model.module.port;

import com.agapia.graphicalinterface.model.common.ValueObject;

import java.util.List;

import static java.util.Arrays.asList;

public class Variable extends ValueObject {
    private final VariableName name;
    private final VariableType type;
    //ok nu ne ocupam de valori
    public Variable(VariableName name, VariableType type) {
        this.name = name;
        this.type = type;
    }
    public Variable()
    {
        this.name = new VariableName();
        this.type = new VariableType();
    }

    public VariableName getName() {
        return name;
    }

    public VariableType getType() {
        return type;
    }

    @Override
    protected List<Object> attributesIncludedInEqualityCheck() {
        return asList(name, type);
    }

    public String print() {
        if(name.getValue().endsWith("[]")) {
            return "(" + type + " " + name + ";)";
        }
        else {
            return name.getValue() + ":" + type.getValue();
        }
    }

    @Override
    public String toString() {
        return "Variable{" +
                "name=" + name.getValue() +
                ", type=" + type.getValue() +
                '}';
    }
}
