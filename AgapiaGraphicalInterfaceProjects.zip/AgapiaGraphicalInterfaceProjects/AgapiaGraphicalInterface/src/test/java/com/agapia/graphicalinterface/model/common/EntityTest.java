package com.agapia.graphicalinterface.model.common;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.*;

public class EntityTest {

    @Test
    public void objects_belonging_to_different_classes_should_not_be_equal() {
        EntityA entityA = new EntityA("abc", "xyz");
        EntityB entityB = new EntityB("abc", "xyz");

        assertFalse(entityA.equals(entityB));
    }

    @Test
    public void same_class_objects_with_different_ids_should_not_be_equal() {
        EntityA entity1 = new EntityA("abc", "xyz");
        EntityA entity2 = new EntityA("def", "xyz");

        assertNotEquals(entity1, entity2);
    }

    @Test
    public void same_class_objects_with_equal_ids_should_be_equal() {
        EntityA entity1 = new EntityA("abc", "xyz");
        EntityA entity2 = new EntityA("abc", "trv");

        assertEquals(entity1, entity2);
    }

    private static class EntityA extends Entity<String> {
        private String field;
        public EntityA(String id, String field) {
            super(id);
            this.field = field;
        }
    }

    private static class EntityB extends Entity<String> {
        private String field;
        public EntityB(String id, String field) {
            super(id);
            this.field = field;
        }
    }
}
