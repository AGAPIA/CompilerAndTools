package com.agapia.graphicalinterface.integration;

import com.agapia.graphicalinterface.GraphicalInterfaceApplication;
import com.agapia.graphicalinterface.service.ExportAgapiaTxt;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = GraphicalInterfaceApplication.class)
@AutoConfigureMockMvc
public class ExportIntegrationTest {

    private static final String PATH_TO_HORIZONTAL_TEST_IF_PRIME = "src/test/resources/export/Horizontal_TestIfPrime.txt";
    private static final String PATH_TO_VERTICAL_TEST_IF_PRIME = "src/test/resources/export/Vertical_TestIfPrime.txt";
    private static final String PATH_TO_DIAGONAL_GET_MINIMUM_OF_TWO_NUMBERS = "src/test/resources/export/Diagonal_GetMinimumOfTwoNumbers.txt";

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ExportAgapiaTxt exportAgapiaTxt;

    @Test
    public void horizontal_test_if_prime() throws Exception {
        mockMvc.perform(post("/agapia/export")
                .contentType(MediaType.APPLICATION_JSON)
                .content(JsonResource.getHorizontalTestIfPrimeJson()))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(content().bytes(ReadAllFromFile.read(PATH_TO_HORIZONTAL_TEST_IF_PRIME)));
    }

    @Test
    public void vertical_test_if_prime() throws Exception {
        mockMvc.perform(post("/agapia/export")
                .contentType(MediaType.APPLICATION_JSON)
                .content(JsonResource.getVerticalTestIfPrimeJson()))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(content().bytes(ReadAllFromFile.read(PATH_TO_VERTICAL_TEST_IF_PRIME)));
    }

    @Test
    public void diagonal_test_get_minimum_of_two_numbers() throws Exception {
        mockMvc.perform(post("/agapia/export")
                .contentType(MediaType.APPLICATION_JSON)
                .content(JsonResource.getDiagonalGetMinimumOfTwoNumbersJson()))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(content().bytes(ReadAllFromFile.read(PATH_TO_DIAGONAL_GET_MINIMUM_OF_TWO_NUMBERS)));
    }

}
