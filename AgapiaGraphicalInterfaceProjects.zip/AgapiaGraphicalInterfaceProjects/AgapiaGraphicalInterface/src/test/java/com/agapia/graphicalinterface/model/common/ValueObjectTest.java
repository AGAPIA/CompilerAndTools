package com.agapia.graphicalinterface.model.common;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class ValueObjectTest {

    @Test
    public void objects_belonging_to_different_classes_should_not_be_equal() {
        ValObjA objA = new ValObjA("abc", 1);
        ValObjB objB = new ValObjB("abc", 1);

        assertFalse(objA.equals(objB));
    }

    @Test
    public void same_class_objects_with_different_field_should_not_be_equal() {
        ValObjA obj1 = new ValObjA("abc", 1);
        ValObjA obj2 = new ValObjA("def", 1);
        assertNotEquals(obj1, obj2);
    }

    @Test
    public void same_class_objects_with_equal_fields_should_be_equal() {
        ValObjA obj1 = new ValObjA("abc", 1);
        ValObjA obj2 = new ValObjA("abc", 1);
        assertEquals(obj1, obj2);
    }

    private static class ValObjA extends ValueObject {
        private final String field;
        private final int number;

        public ValObjA(String field, int number) {
            this.field = field;
            this.number = number;
        }

        @Override
        protected List<Object> attributesIncludedInEqualityCheck() {
            return Arrays.asList(field, number);
        }
    }

    private static class ValObjB extends ValueObject {
        private final String field;
        private final int number;

        public ValObjB(String field, int number) {
            this.field = field;
            this.number = number;
        }

        @Override
        protected List<Object> attributesIncludedInEqualityCheck() {
            return Arrays.asList(field, number);
        }
    }
}
