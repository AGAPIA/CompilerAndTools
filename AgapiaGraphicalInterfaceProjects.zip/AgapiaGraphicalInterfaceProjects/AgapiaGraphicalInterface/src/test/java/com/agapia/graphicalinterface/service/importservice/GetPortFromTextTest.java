package com.agapia.graphicalinterface.service.importservice;

import com.agapia.graphicalinterface.model.module.port.Port;
import com.agapia.graphicalinterface.model.module.port.Variable;
import com.agapia.graphicalinterface.model.module.port.VariableName;
import com.agapia.graphicalinterface.model.module.port.VariableType;
import org.junit.Test;

import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;

public class GetPortFromTextTest {

    @Test
    public void should_return_empty_list_for_nil_port() {
        List<Port> result = GetPortFromText.get("nil");
        assertThat(result).isEmpty();
    }

    @Test
    public void should_return_simple_int_port() {
        List<Port> result = GetPortFromText.get("n: int");
        assertThat(result)
                .hasSize(1)
                .containsExactly(new Port(singletonList(new Variable(new VariableName("n"), new VariableType("int")))));
    }

    @Test
    public void should_return_1_port_with_2_variables() {
        List<Port> result = GetPortFromText.get("n: int, m: int");
        assertThat(result)
                .hasSize(1)
                .containsExactly(
                        new Port(asList(
                                new Variable(new VariableName("n"), new VariableType("int")),
                                new Variable(new VariableName("m"), new VariableType("int"))
                        ))
                );
    }

    @Test
    public void should_return_2_ports_with_1_variable_each() {
        List<Port> result = GetPortFromText.get("n: int; m: int");
        assertThat(result)
                .hasSize(2)
                .containsExactly(
                        new Port(singletonList(new Variable(new VariableName("n"), new VariableType("int")))),
                        new Port(singletonList(new Variable(new VariableName("m"), new VariableType("int"))))
                );
    }

    @Test
    public void should_return_2_ports() {
        List<Port> result = GetPortFromText.get("n: int; x: int, y: int");
        assertThat(result)
                .hasSize(2)
                .containsExactly(
                        new Port(singletonList(new Variable(new VariableName("n"), new VariableType("int")))),
                        new Port(asList(
                                new Variable(new VariableName("x"), new VariableType("int")),
                                new Variable(new VariableName("y"), new VariableType("int"))
                        ))
                );
    }
}
