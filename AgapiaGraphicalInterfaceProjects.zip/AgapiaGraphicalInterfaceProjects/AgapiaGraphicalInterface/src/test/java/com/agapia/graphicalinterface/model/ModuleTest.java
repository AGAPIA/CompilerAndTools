package com.agapia.graphicalinterface.model;

import com.agapia.graphicalinterface.model.module.Module;
import com.agapia.graphicalinterface.model.module.ModuleId;
import com.agapia.graphicalinterface.model.module.ModuleType;
import com.agapia.graphicalinterface.model.module.port.*;
import org.junit.jupiter.api.Test;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

public class ModuleTest {
    /*
    module EXAMPLE {listen nil}{read m: int}
    {
    }
    {speak n:int, b: boolean}{write i: int; a: boolean, x: float}
     */

    @Test
    public void parse_module() {
        //not a test
        //just how I'm thinking to represent a module
        ModulePort listenPort = new ModulePort(null, emptyList());
        ModulePort readPort = new ModulePort(null,
                singletonList(new Port(singletonList(
                        new Variable(new VariableName("m"), new VariableType("int"))))
                )
        );
        ModulePort speakPort = new ModulePort(null,
                singletonList(new Port(asList(
                                new Variable(new VariableName("n"), new VariableType("int")),
                                new Variable(new VariableName("b"), new VariableType("boolean"))))
                )
        );
        ModulePort writePort = new ModulePort(null,
                asList(new Port(singletonList(
                                new Variable(new VariableName("i"), new VariableType("int")))),
                        new Port(asList(
                                new Variable(new VariableName("a"), new VariableType("boolean")),
                                new Variable(new VariableName("x"), new VariableType("float"))))
                )
        );

        Module expected = new Module.Builder()
                .id(new ModuleId(1))
                .name("EXAMPLE")
                .type(ModuleType.USER_DEFINED)
                .parentId(new ModuleId(0))
                .listenPort(listenPort)
                .readPort(readPort)
                .speakPort(speakPort)
                .writePort(writePort)
                .build();
    }
}
