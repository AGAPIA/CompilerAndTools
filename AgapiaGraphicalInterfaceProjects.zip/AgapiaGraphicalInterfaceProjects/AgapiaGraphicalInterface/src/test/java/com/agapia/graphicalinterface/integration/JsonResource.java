package com.agapia.graphicalinterface.integration;

import com.agapia.graphicalinterface.controller.ModulePortRepresentation;
import com.agapia.graphicalinterface.controller.ModuleRepresentation;
import com.agapia.graphicalinterface.controller.PortRepresentation;
import com.agapia.graphicalinterface.controller.VariableRepresentation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

public class JsonResource {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static String getHorizontalTestIfPrimeJson() throws JsonProcessingException {
        List<ModuleRepresentation> modules = new ArrayList<>();

        //MAIN MODULE
        ModuleRepresentation mainModule = new ModuleRepresentation();
        mainModule.id = 0;
        mainModule.name = "MAIN";
        mainModule.type = "USER_DEFINED";
        mainModule.listenPort = new ModulePortRepresentation();
        mainModule.readPort = new ModulePortRepresentation();
        mainModule.speakPort = new ModulePortRepresentation();
        mainModule.writePort = new ModulePortRepresentation();
        modules.add(mainModule);

        //READ MODULE
        ModuleRepresentation readModule = new ModuleRepresentation();
        readModule.id = 1;
        readModule.name = "READ";
        readModule.type = "USER_DEFINED";
        readModule.parentId = 0;
        readModule.listenPort = new ModulePortRepresentation();
        readModule.readPort = new ModulePortRepresentation();
        readModule.speakPort = new ModulePortRepresentation();
        readModule.speakPort.connectsTo = 2;
        readModule.speakPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        readModule.writePort = new ModulePortRepresentation();
        modules.add(readModule);

        //PRIMETEST MODULE
        ModuleRepresentation primetestModule = new ModuleRepresentation();
        primetestModule.id = 2;
        primetestModule.name = "PRIMETEST";
        primetestModule.type = "USER_DEFINED";
        primetestModule.parentId = 0;
        primetestModule.listenPort = new ModulePortRepresentation();
        primetestModule.listenPort.connectsTo = 1;
        primetestModule.listenPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        primetestModule.readPort = new ModulePortRepresentation();
        primetestModule.speakPort = new ModulePortRepresentation();
        primetestModule.writePort = new ModulePortRepresentation();
        modules.add(primetestModule);


        return OBJECT_MAPPER.writeValueAsString(modules);
    }

    public static String getVerticalTestIfPrimeJson() throws JsonProcessingException {
        List<ModuleRepresentation> modules = new ArrayList<>();

        //MAIN MODULE
        ModuleRepresentation mainModule = new ModuleRepresentation();
        mainModule.id = 0;
        mainModule.name = "MAIN";
        mainModule.type = "USER_DEFINED";
        mainModule.listenPort = new ModulePortRepresentation();
        mainModule.readPort = new ModulePortRepresentation();
        mainModule.speakPort = new ModulePortRepresentation();
        mainModule.writePort = new ModulePortRepresentation();
        modules.add(mainModule);

        //READ MODULE
        ModuleRepresentation readModule = new ModuleRepresentation();
        readModule.id = 1;
        readModule.name = "READ";
        readModule.type = "USER_DEFINED";
        readModule.parentId = 0;
        readModule.listenPort = new ModulePortRepresentation();
        readModule.readPort = new ModulePortRepresentation();
        readModule.speakPort = new ModulePortRepresentation();
        readModule.writePort = new ModulePortRepresentation();
        readModule.writePort.connectsTo = 2;
        readModule.writePort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        modules.add(readModule);

        //PRIMETEST MODULE
        ModuleRepresentation primetestModule = new ModuleRepresentation();
        primetestModule.id = 2;
        primetestModule.name = "PRIMETEST";
        primetestModule.type = "USER_DEFINED";
        primetestModule.parentId = 0;
        primetestModule.listenPort = new ModulePortRepresentation();
        primetestModule.readPort = new ModulePortRepresentation();
        primetestModule.readPort.connectsTo = 1;
        primetestModule.readPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        primetestModule.speakPort = new ModulePortRepresentation();
        primetestModule.writePort = new ModulePortRepresentation();
        modules.add(primetestModule);


        return OBJECT_MAPPER.writeValueAsString(modules);
    }

    public static String getDiagonalGetMinimumOfTwoNumbersJson() throws JsonProcessingException {
        List<ModuleRepresentation> modules = new ArrayList<>();

        //MAIN MODULE
        ModuleRepresentation mainModule = new ModuleRepresentation();
        mainModule.id = 0;
        mainModule.name = "MAIN";
        mainModule.type = "USER_DEFINED";
        mainModule.listenPort = new ModulePortRepresentation();
        mainModule.readPort = new ModulePortRepresentation();
        mainModule.speakPort = new ModulePortRepresentation();
        mainModule.writePort = new ModulePortRepresentation();
        modules.add(mainModule);

        //READ MODULE
        ModuleRepresentation readModule = new ModuleRepresentation();
        readModule.id = 1;
        readModule.name = "READ";
        readModule.type = "USER_DEFINED";
        readModule.parentId = 0;
        readModule.listenPort = new ModulePortRepresentation();
        readModule.readPort = new ModulePortRepresentation();
        readModule.speakPort = new ModulePortRepresentation();
        readModule.speakPort.connectsTo = 2;
        readModule.speakPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        readModule.writePort = new ModulePortRepresentation();
        readModule.writePort.connectsTo = 2;
        readModule.writePort.ports.add(new PortRepresentation(asList(new VariableRepresentation("m", "int"))));
        modules.add(readModule);

        //MIN MODULE
        ModuleRepresentation primetestModule = new ModuleRepresentation();
        primetestModule.id = 2;
        primetestModule.name = "MIN";
        primetestModule.type = "USER_DEFINED";
        primetestModule.parentId = 0;
        primetestModule.listenPort = new ModulePortRepresentation();
        primetestModule.listenPort.connectsTo = 1;
        primetestModule.listenPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        primetestModule.readPort = new ModulePortRepresentation();
        primetestModule.readPort.connectsTo = 1;
        primetestModule.readPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("m", "int"))));
        primetestModule.speakPort = new ModulePortRepresentation();
        primetestModule.writePort = new ModulePortRepresentation();
        modules.add(primetestModule);


        return OBJECT_MAPPER.writeValueAsString(modules);
    }

    public static String getParenthesisTestJson() throws JsonProcessingException {
        List<ModuleRepresentation> modules = new ArrayList<>();

        //MAIN MODULE
        ModuleRepresentation mainModule = new ModuleRepresentation();
        mainModule.id = 0;
        mainModule.name = "MAIN";
        mainModule.type = "USER_DEFINED";
        mainModule.listenPort = new ModulePortRepresentation();
        mainModule.readPort = new ModulePortRepresentation();
        mainModule.speakPort = new ModulePortRepresentation();
        mainModule.writePort = new ModulePortRepresentation();
        modules.add(mainModule);

        //READ MODULE
        ModuleRepresentation readModule = new ModuleRepresentation();
        readModule.id = 1;
        readModule.name = "READ";
        readModule.type = "USER_DEFINED";
        readModule.parentId = 6;
        readModule.listenPort = new ModulePortRepresentation();
        readModule.readPort = new ModulePortRepresentation();
        readModule.speakPort = new ModulePortRepresentation();
        readModule.speakPort.connectsTo = 2;
        readModule.speakPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        readModule.writePort = new ModulePortRepresentation();
        modules.add(readModule);

        //PRIMETEST MODULE
        ModuleRepresentation primetestModule = new ModuleRepresentation();
        primetestModule.id = 2;
        primetestModule.name = "PRIMETEST";
        primetestModule.type = "USER_DEFINED";
        primetestModule.parentId = 6;
        primetestModule.listenPort = new ModulePortRepresentation();
        primetestModule.listenPort.connectsTo = 1;
        primetestModule.listenPort.ports.add(new PortRepresentation(asList(new VariableRepresentation("n", "int"))));
        primetestModule.readPort = new ModulePortRepresentation();
        primetestModule.speakPort = new ModulePortRepresentation();
        primetestModule.writePort = new ModulePortRepresentation();
        modules.add(primetestModule);

        //SOME_NEW_MODULE
        ModuleRepresentation someNewModule = new ModuleRepresentation();
        someNewModule.id = 3;
        someNewModule.name = "SOME_NEW_MODULE";
        someNewModule.type = "USER_DEFINED";
        someNewModule.parentId = 0;
        someNewModule.listenPort = new ModulePortRepresentation();
        someNewModule.listenPort.connectsTo = 6;
        someNewModule.readPort = new ModulePortRepresentation();
        someNewModule.readPort.connectsTo = 6;
        someNewModule.speakPort = new ModulePortRepresentation();
        someNewModule.writePort = new ModulePortRepresentation();
        modules.add(someNewModule);

        //A
        ModuleRepresentation a = new ModuleRepresentation();
        a.id = 4;
        a.name = "A";
        a.type = "USER_DEFINED";
        a.parentId = 3;
        a.listenPort = new ModulePortRepresentation();
        a.readPort = new ModulePortRepresentation();
        a.speakPort = new ModulePortRepresentation();
        a.writePort = new ModulePortRepresentation();
        a.writePort.connectsTo = 5;
        modules.add(a);

        //B
        ModuleRepresentation b = new ModuleRepresentation();
        b.id = 5;
        b.name = "B";
        b.type = "USER_DEFINED";
        b.parentId = 3;
        b.listenPort = new ModulePortRepresentation();
        b.readPort = new ModulePortRepresentation();
        b.readPort.connectsTo = 4;
        b.speakPort = new ModulePortRepresentation();
        b.writePort = new ModulePortRepresentation();
        modules.add(b);

        //PARENTHESIS
        ModuleRepresentation parenthesis = new ModuleRepresentation();
        parenthesis.id = 6;
        parenthesis.name = "PARENTHESIS";
        parenthesis.type = "PARENTHESIS";
        parenthesis.parentId = 0;
        parenthesis.listenPort = new ModulePortRepresentation();
        parenthesis.readPort = new ModulePortRepresentation();
        parenthesis.speakPort = new ModulePortRepresentation();
        parenthesis.speakPort.connectsTo = 3;
        parenthesis.writePort = new ModulePortRepresentation();
        parenthesis.writePort.connectsTo = 3;
        modules.add(parenthesis);

        return OBJECT_MAPPER.writeValueAsString(modules);
    }

    private JsonResource() {
    }
}
