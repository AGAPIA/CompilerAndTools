package com.agapia.graphicalinterface.integration;

import com.agapia.graphicalinterface.GraphicalInterfaceApplication;
import com.agapia.graphicalinterface.service.ImportAgapiaTxt;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = GraphicalInterfaceApplication.class)
@AutoConfigureMockMvc
public class ImportIntegrationTest {

    private static final String ANY_NAME = "filename";
    private static final String PATH_TO_HORIZONTAL_TEST_IF_PRIME = "src/test/resources/import/Horizontal_TestIfPrime.txt";
    private static final String PATH_TO_VERTICAL_TEST_IF_PRIME = "src/test/resources/import/Vertical_TestIfPrime.txt";
    private static final String PATH_TO_DIAGONAL_GET_MINIMUM_OF_TWO_NUMBERS = "src/test/resources/import/Diagonal_GetMinimumOfTwoNumbers.txt";
    private static final String PATH_TO_PARENTHESIS_TEST = "src/test/resources/import/Parenthesis_Test.txt";

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ImportAgapiaTxt importAgapiaTxt;

    @Test
    public void horizontal_test_if_prime() throws Exception {
        mockMvc.perform(multipart("/agapia/import")
                .file(new MockMultipartFile(
                        "file", ANY_NAME, MediaType.TEXT_PLAIN_VALUE,
                        ReadAllFromFile.read(PATH_TO_HORIZONTAL_TEST_IF_PRIME))))
                .andExpect(status().isOk())
                .andExpect(content().json(JsonResource.getHorizontalTestIfPrimeJson()));
    }

    @Test
    public void vertical_test_if_prime() throws Exception {
        mockMvc.perform(multipart("/agapia/import")
                .file(new MockMultipartFile(
                        "file", ANY_NAME, MediaType.TEXT_PLAIN_VALUE,
                        ReadAllFromFile.read(PATH_TO_VERTICAL_TEST_IF_PRIME))))
                .andExpect(status().isOk())
                .andExpect(content().json(JsonResource.getVerticalTestIfPrimeJson()));
    }

    @Test
    public void diagonal_test_get_minimum_of_two_numbers() throws Exception {
        mockMvc.perform(multipart("/agapia/import")
                .file(new MockMultipartFile(
                        "file", ANY_NAME, MediaType.TEXT_PLAIN_VALUE,
                        ReadAllFromFile.read(PATH_TO_DIAGONAL_GET_MINIMUM_OF_TWO_NUMBERS))))
                .andExpect(status().isOk())
                .andExpect(content().json(JsonResource.getDiagonalGetMinimumOfTwoNumbersJson()));
    }

//    @Test
//    public void diagonal_test_parenthesis() throws Exception {
//        mockMvc.perform(multipart("/agapia/import")
//                .file(new MockMultipartFile(
//                        "file", ANY_NAME, MediaType.TEXT_PLAIN_VALUE,
//                        ReadAllFromFile.read(PATH_TO_PARENTHESIS_TEST))))
//                .andExpect(status().isOk())
//                .andExpect(content().json(JsonResource.getParenthesisTestJson()));
//    }
}
