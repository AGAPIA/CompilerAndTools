import { Component, EventEmitter, Input, Output } from '@angular/core';
import * as go from 'gojs';
import { MessageService } from 'primeng/api';
import { AgapiaModulePort } from '../models/agapia-module-port.model';
import { AgapiaModule, AgapiaModuleType } from '../models/agapia-module.model';
import { AgapiaPort } from '../models/agapia-port.model';
import { AgapiaVariable } from '../models/agapia-variable.model';
import { ModuleService } from '../service/module.service';


@Component({
  selector: 'app-inspector',
  templateUrl: './inspector.component.html',
  styleUrls: ['./inspector.component.scss']
})
export class InspectorComponent {

  public _selectedNode: go.Node;
  public data = {
    key: null,
    name: null,
    color: null,
    read: null,
    write: null,
    listen: null,
    speak: null,
  };

  private correspondentModule: AgapiaModule = null;

  @Input()
  public model: go.Model;

  @Input()
  idParentModule: number = 0;

  @Output()
  public onFormChange: EventEmitter<any> = new EventEmitter<any>();

  @Input()
  get selectedNode() { return this._selectedNode; }
  set selectedNode(node: go.Node) {
    if (node) {
      this._selectedNode = node;
      this.data.key = this._selectedNode.data.key;
      this.data.name = this._selectedNode.data.name;
      this.data.color = this._selectedNode.data.color;
      this.data.read = this._selectedNode.data.read;
      this.data.write = this._selectedNode.data.write;
      this.data.listen = this._selectedNode.data.listen;
      this.data.speak = this._selectedNode.data.speak;
      this.correspondentModule = this.moduleService.getModuleByDiagramNodeKeyAndParentModule(this._selectedNode.data.key, this.idParentModule);
    } else {
      this._selectedNode = null;
      this.data.key = null;
      this.data.name = null;
      this.data.color = null;
      this.data.read = null;
      this.data.write = null;
      this.data.listen = null;
      this.data.speak = null;
      this.correspondentModule = null;
    }
  }

  constructor(
    private moduleService: ModuleService,
    private messageService: MessageService
  ) { }

  moduleIsUserDefined(): boolean {
    return this.correspondentModule.type === AgapiaModuleType.USER_DEFINED;
  }

  onNameChange(event) {
    if (this.isValidName(this.data.name)) {
      this.correspondentModule.name = this.data.name;
      this.onFormChange.emit(this.data);
    }
    else {
      this.displayErrorMessage("Invalid name", "\'" + this.data.name + "\' is not a valid name");
      this.data.name = this.correspondentModule.name;
    }
  }

  onColorChange(event) {
    this.correspondentModule.color = this.data.color;
    this.onFormChange.emit(this.data);
  }

  onReadChange(event) {
    var readPort = new AgapiaModulePort();
    readPort.connectsTo = this.correspondentModule.readPort.connectsTo;
    readPort.ports = this.parseModulePortFromText(this.data.read);
    console.log(readPort.ports);
    if (readPort.ports !== null) {
      console.log("error");
      this.correspondentModule.readPort = readPort;

      this.data.read = this.moduleService.portTextFromAgapiaPorts(readPort.ports);
      if (this.correspondentModule.parentId !== null) this.moduleService.updateParentModule(this.correspondentModule.parentId);
      this.onFormChange.emit(this.data);
    }
    else {
      //restore old value
      this.data.read = this.moduleService.portTextFromAgapiaPorts(this.correspondentModule.readPort.ports);
    }
  }

  onWriteChange(event) {
    var writePort = new AgapiaModulePort();
    writePort.connectsTo = this.correspondentModule.writePort.connectsTo;
    writePort.ports = this.parseModulePortFromText(this.data.write);
    if (writePort.ports !== null) {
      this.correspondentModule.writePort = writePort;

      this.data.write = this.moduleService.portTextFromAgapiaPorts(writePort.ports);
      if (this.correspondentModule.parentId !== null) this.moduleService.updateParentModule(this.correspondentModule.parentId);
      this.onFormChange.emit(this.data);
    }
    else {
      //restore old value
      this.data.write = this.moduleService.portTextFromAgapiaPorts(this.correspondentModule.writePort.ports);
    }
  }

  onListenChange(event) {
    var listenPort = new AgapiaModulePort();
    listenPort.connectsTo = this.correspondentModule.listenPort.connectsTo;
    listenPort.ports = this.parseModulePortFromText(this.data.listen);
    if (listenPort.ports !== null) {
      this.correspondentModule.listenPort = listenPort;

      this.data.listen = this.moduleService.portTextFromAgapiaPorts(listenPort.ports);
      if (this.correspondentModule.parentId !== null) this.moduleService.updateParentModule(this.correspondentModule.parentId);
      this.onFormChange.emit(this.data);
    }
    else {
      //restore old value
      this.data.listen = this.moduleService.portTextFromAgapiaPorts(this.correspondentModule.listenPort.ports);
    }
  }

  onSpeakChange(event) {
    var speakPort = new AgapiaModulePort();
    speakPort.connectsTo = this.correspondentModule.speakPort.connectsTo;
    speakPort.ports = this.parseModulePortFromText(this.data.speak);
    if (speakPort.ports !== null) {
      this.correspondentModule.speakPort = speakPort;

      this.data.speak = this.moduleService.portTextFromAgapiaPorts(speakPort.ports);
      if (this.correspondentModule.parentId !== null) this.moduleService.updateParentModule(this.correspondentModule.parentId);
      this.onFormChange.emit(this.data);
    }
    else {
      this.data.speak = this.moduleService.portTextFromAgapiaPorts(this.correspondentModule.speakPort.ports);
    }
  }

  private parseModulePortFromText(portText: string): Array<AgapiaPort> {
    portText = portText.trim();
    if (portText === 'nil' || portText === '') {
      return [];
    }

    const ports = portText.split(';');
    var agapiaPorts: Array<AgapiaPort> = [];

    ports.forEach(port => {
      if (port === '') {
        this.displayErrorMessage("Cannot parse agapia port", "Unexpected \';\' found");
        agapiaPorts = null;
      }
      else {
        const variables = port.trim().split(',');
        var agapiaVariables: Array<AgapiaVariable> = [];
        variables.forEach(variable => {
          if (variable === '') {
            this.displayErrorMessage("Cannot parse agapia port", "Unexpected \',\' found");
            agapiaPorts = null;
          }
          else {
            let vari = variable.trim();
            if (vari.endsWith("[]")) {
              //interative variable
              const varParts = vari.split(' ');
              if (varParts.length !== 2 || varParts[0] === '' || varParts[1] === '') {
                this.displayErrorMessage("Cannot parse agapia port", "Cannot parse [] variable");
                agapiaPorts = null;
              }
              else {
                var agapiaVariable = new AgapiaVariable();
                agapiaVariable.type = varParts[0].trim();
                agapiaVariable.name = varParts[1].trim();
                agapiaVariables.push(agapiaVariable);
              }
            }
            else {
              const varParts = variable.split(':');
              if (varParts.length !== 2 || varParts[0] === '' || varParts[1] === '') {
                this.displayErrorMessage("Cannot parse agapia port", "Cannot parse variable, no \':\' found");
                agapiaPorts = null;
              }
              else {
                var agapiaVariable = new AgapiaVariable();
                agapiaVariable.name = varParts[0].trim();
                agapiaVariable.type = varParts[1].trim();
                agapiaVariables.push(agapiaVariable);
              }
            }
          }
        });
        if (agapiaPorts !== null) {
          var agapiaPort = new AgapiaPort();
          agapiaPort.variables = agapiaVariables;
          agapiaPorts.push(agapiaPort);
        }
      }
    });

    return agapiaPorts;
  }

  isValidName(name: string): boolean {
    name = name.trim();
    if(name === '') {
      return false;
    }
    for(let i=0;i<name.length;i++) {
      if(!('A' <= name[i] && name[i] <= 'Z' || '0' <= name[i] && name[i] <= '9' || name[i] === '_')) {
        return false;
      }
    }
    return true;
  }

  displayErrorMessage(summary: string, detail: string) {
    this.messageService.add({ severity: 'error', summary: summary, detail: detail });
  }

}
