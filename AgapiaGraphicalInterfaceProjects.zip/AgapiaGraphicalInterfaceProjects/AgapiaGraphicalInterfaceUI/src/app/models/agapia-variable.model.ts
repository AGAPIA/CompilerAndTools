
export class AgapiaVariable {
    name: string;
    type: string;
}