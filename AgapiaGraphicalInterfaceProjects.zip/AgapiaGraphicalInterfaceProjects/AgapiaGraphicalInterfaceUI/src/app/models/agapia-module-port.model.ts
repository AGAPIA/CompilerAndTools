import { AgapiaPort } from "./agapia-port.model";

export class AgapiaModulePort {
    connectsTo?: number = null;
    ports: Array<AgapiaPort> = [];
}