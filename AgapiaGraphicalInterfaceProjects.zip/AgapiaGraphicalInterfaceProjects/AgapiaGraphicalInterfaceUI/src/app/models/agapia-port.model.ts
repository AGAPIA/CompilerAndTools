import { AgapiaVariable } from "./agapia-variable.model";

export class AgapiaPort {
    variables: Array<AgapiaVariable> = [];
}