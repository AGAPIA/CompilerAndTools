import { Key } from "gojs";
import { AgapiaModulePort } from "./agapia-module-port.model";

export class AgapiaModule {
    id: number;
    name: string;
    type: AgapiaModuleType;
    parentId?: number = null;
    listenPort: AgapiaModulePort = new AgapiaModulePort();
    readPort: AgapiaModulePort = new AgapiaModulePort();
    speakPort: AgapiaModulePort = new AgapiaModulePort();
    writePort: AgapiaModulePort = new AgapiaModulePort(); 

    diagramNodeKey?: Key = null;
    color?: string = null;
}

export enum AgapiaModuleType {
    USER_DEFINED = "USER_DEFINED",
    PARENTHESIS = "PARENTHESIS",
    FOREACH = "FOREACH"
}