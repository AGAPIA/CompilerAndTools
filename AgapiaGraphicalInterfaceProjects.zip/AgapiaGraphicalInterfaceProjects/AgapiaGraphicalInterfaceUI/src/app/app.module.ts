import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { GojsAngularModule } from 'gojs-angular';
import {FileUploadModule} from 'primeng/fileupload';
import {ToastModule} from 'primeng/toast';


import { AppComponent } from './app.component';
import { InspectorComponent } from './inspector/inspector.component';
import { MessageService } from 'primeng/api';

@NgModule({
  declarations: [
    AppComponent,
    InspectorComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    GojsAngularModule,
    FileUploadModule,
    ToastModule
  ],
  providers: [MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
