import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExportService {

  constructor(private httpClient: HttpClient) { }

  exportToAgapiaTxt(body: any) : Observable<HttpResponse<Blob>> {
    return this.httpClient.post('http://localhost:8080/agapia/export', body, { responseType: 'blob', observe: 'response' });
  }
}
