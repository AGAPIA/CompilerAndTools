import { TestBed } from '@angular/core/testing';

import { ModuleValidationService } from './module-validation.service';

describe('ModuleValidationService', () => {
  let service: ModuleValidationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModuleValidationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
