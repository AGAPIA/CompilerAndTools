import { variable } from '@angular/compiler/src/output/output_ast';
import { Injectable } from '@angular/core';
import { Key } from 'gojs';
import { AgapiaModule, AgapiaModuleType } from '../models/agapia-module.model';
import { AgapiaPort } from '../models/agapia-port.model';
import { AgapiaVariable } from '../models/agapia-variable.model';

@Injectable({
  providedIn: 'root'
})
export class ModuleService {

  private modules: Array<AgapiaModule> = this.initializeAgapiaModules();
  private nextId: number = 1;

  constructor() { }

  public resetModuleList(newModules: Array<AgapiaModule>) {
    this.modules = newModules;

    //reset nextId
    this.nextId = 0;
    this.modules.forEach(module => {
      //set diagramKey and color
      module.diagramNodeKey = module.id === 0 ? null : module.id * -1;
      if(module.type === AgapiaModuleType.USER_DEFINED) {
        module.color = 'Moccasin';
      }
      else if(module.type === AgapiaModuleType.PARENTHESIS) {
        module.color = 'Orange';
      }
      else if(module.type === AgapiaModuleType.FOREACH) {
        module.color = 'IndianRed';
      }

      //set nextId
      if(module.id > this.nextId) this.nextId = module.id;
    });
    this.nextId++;
  }

  public getId(): number {
    this.nextId++;
    return this.nextId - 1;
  }

  public getAllModules(): Array<AgapiaModule> {
    return this.modules;
  }

  public getModuleById(id: number): AgapiaModule {
    const index = this.modules.findIndex(module => module.id === id);
    if (index > -1) {
      return this.modules[index];
    }
    return null;
  }

  public getAllModulesByParent(parentId: number) {
    return this.modules.filter(module => module.parentId !== null && module.parentId === parentId);
  }

  public getModuleByDiagramNodeKeyAndParentModule(diagramNodeKey: Key, parentId: number): AgapiaModule {
    const index = this.modules.findIndex(module => module.diagramNodeKey !== null && module.parentId !== null
      && module.diagramNodeKey === diagramNodeKey && module.parentId === parentId);
    if (index > -1) {
      return this.modules[index];
    }
    return null;
  }

  public addModule(agapiaModule: AgapiaModule): void {
    this.modules.push(agapiaModule);
  }

  public addConnectionSpeakListen(fromAgapiaModule: AgapiaModule, toAgapiaModule: AgapiaModule) {
    fromAgapiaModule.speakPort.connectsTo = toAgapiaModule.id;
    toAgapiaModule.listenPort.connectsTo = fromAgapiaModule.id;
  }

  public addConnectionWriteRead(fromAgapiaModule: AgapiaModule, toAgapiaModule: AgapiaModule) {
    fromAgapiaModule.writePort.connectsTo = toAgapiaModule.id;
    toAgapiaModule.readPort.connectsTo = fromAgapiaModule.id;
  }

  public removeModuleByDiagramNodeKeyAndParentModule(diagramNodeKey: Key, parentId: number): void {
    const index = this.modules.findIndex(module => module.diagramNodeKey !== null && module.parentId !== null
      && module.diagramNodeKey === diagramNodeKey && module.parentId === parentId);
    const agapiaModule = this.modules[index];

    //remove connections from other modules
    if(agapiaModule.readPort.connectsTo !== null) {
      this.getModuleById(agapiaModule.readPort.connectsTo).writePort.connectsTo = null;
    }
    if(agapiaModule.speakPort.connectsTo !== null) {
      this.getModuleById(agapiaModule.speakPort.connectsTo).listenPort.connectsTo = null;
    }
    if(agapiaModule.writePort.connectsTo !== null) {
      this.getModuleById(agapiaModule.writePort.connectsTo).readPort.connectsTo = null;
    }
    if(agapiaModule.listenPort.connectsTo !== null) {
      this.getModuleById(agapiaModule.listenPort.connectsTo).speakPort.connectsTo = null;
    }

    //remove module
    if (index > -1) {
      this.modules.splice(index, 1);
    }
  }

  public removeConnectionSpeakListen(fromAgapiaModule: AgapiaModule, toAgapiaModule: AgapiaModule) {
    fromAgapiaModule.speakPort.connectsTo = null;
    toAgapiaModule.listenPort.connectsTo = null;
  }

  public removeConnectionWriteRead(fromAgapiaModule: AgapiaModule, toAgapiaModule: AgapiaModule) {
    fromAgapiaModule.writePort.connectsTo = null;
    toAgapiaModule.readPort.connectsTo = null;
  }

  public portTextFromAgapiaPorts(agapiaPorts: Array<AgapiaPort>): string {
    if(agapiaPorts.length === 0) {
      return 'nil';
    }

    var portText = this.textFromAgapiaVariables(agapiaPorts[0].variables);
    for (let i = 1; i < agapiaPorts.length; i++) {
      portText = portText + "; " + this.textFromAgapiaVariables(agapiaPorts[i].variables);
    }
    return portText;
  }

  public updateParentModule(moduleId: number) {
    var module = this.getModuleById(moduleId);
    //TODO: also update for FOREACH
    if(module.type == AgapiaModuleType.PARENTHESIS) {
      var children = this.modules.filter(m => m.parentId !== null && m.parentId === module.id);
      if(children.length !== 0) {
        var kidIndex = children.findIndex(kid => kid.listenPort.connectsTo === null && kid.readPort.connectsTo === null);
        if(kidIndex != -1) {
          var kid = children[kidIndex];
          module.listenPort.ports = [... kid.listenPort.ports];
          module.speakPort.ports = [... kid.speakPort.ports];
          module.readPort.ports = [... kid.readPort.ports];
          module.writePort.ports = [... kid.writePort.ports];
          if(kid.speakPort.connectsTo!==null && kid.writePort.connectsTo!==null && kid.speakPort.connectsTo === kid.writePort.connectsTo) {
            kid = this.getModuleById(kid.speakPort.connectsTo);
            module.speakPort.ports = [... kid.speakPort.ports];
            module.writePort.ports = [... kid.writePort.ports];
          }
          else if(kid.speakPort.connectsTo!==null) {
            kid = this.getModuleById(kid.speakPort.connectsTo);
            module.speakPort.ports = [... kid.speakPort.ports];
            kid.writePort.ports.forEach(port => module.writePort.ports.push(port));
            kid.readPort.ports.forEach(port => module.readPort.ports.push(port));
          }
          else if(kid.writePort.connectsTo!==null) {
            kid = this.getModuleById(kid.writePort.connectsTo);
            module.writePort.ports = [... kid.writePort.ports];
            kid.speakPort.ports.forEach(port => module.speakPort.ports.push(port));
            kid.listenPort.ports.forEach(port => module.listenPort.ports.push(port));
          }
        }
      }
    }
  }

  private textFromAgapiaVariables(agapiaVariables: Array<AgapiaVariable>): string {
    var varText = this.textFromAgapiaVariable(agapiaVariables[0]);
    for (let i = 1; i < agapiaVariables.length; i++) {
      varText = varText + ', ' + this.textFromAgapiaVariable(agapiaVariables[i]);
    }
    return varText;
  }

  private textFromAgapiaVariable(agapiaVariable: AgapiaVariable): string {
    if(agapiaVariable.name.endsWith("[]")) {
      //iterative variable
      return agapiaVariable.type + ' ' + agapiaVariable.name;
    }
    else {
      return agapiaVariable.name + ': ' + agapiaVariable.type;
    }
  }

  private initializeAgapiaModules(): Array<AgapiaModule> {
    var mainModule = new AgapiaModule();
    mainModule.id = 0;
    mainModule.name = "MAIN";
    mainModule.type = AgapiaModuleType.USER_DEFINED;
    mainModule.parentId = null;
    return [mainModule];
  }
}
