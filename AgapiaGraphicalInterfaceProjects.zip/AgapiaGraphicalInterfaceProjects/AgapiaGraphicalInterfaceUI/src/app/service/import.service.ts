import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImportService {

  constructor(private httpClient: HttpClient) { }

  importAgapiaTxt(file: any) {
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post('http://localhost:8080/agapia/import', formData);
  }
}
