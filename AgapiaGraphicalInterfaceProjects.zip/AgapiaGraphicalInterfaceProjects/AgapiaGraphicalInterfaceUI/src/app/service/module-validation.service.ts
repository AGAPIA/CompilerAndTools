import { Injectable } from '@angular/core';
import { AgapiaModulePort } from '../models/agapia-module-port.model';
import { AgapiaModule, AgapiaModuleType } from '../models/agapia-module.model';


export interface ValidationMessages {
  errors: Array<string>;
  warnings: Array<string>;
}

@Injectable({
  providedIn: 'root'
})
export class ModuleValidationService {

  constructor() { }

  public validate(modules: Array<AgapiaModule>): ValidationMessages {
    var messages: ValidationMessages = { errors: [], warnings: [] };

    modules.forEach(module => {
      if (module.speakPort.connectsTo !== null && module.writePort.connectsTo !== null
        && module.speakPort.connectsTo !== module.writePort.connectsTo) {
        messages.errors.push(this.getModulePath(module, modules) + ": cannot determine operation order");
      }

      //TODO: update validations after calculating ports of foreach module based on its contents
      if (module.type !== AgapiaModuleType.FOREACH) {

        if (module.speakPort.connectsTo !== null) {
          const moduleThatListens = this.getModuleById(module.speakPort.connectsTo, modules);
          if (moduleThatListens.type !== AgapiaModuleType.FOREACH) {
            if (!this.portsAreCompatible(module.speakPort, moduleThatListens.listenPort)) {
              messages.warnings.push(this.getModulePath(this.getModuleById(module.parentId, modules), modules) + ": incompatible speak-listen connection between modules " + module.name + " " + moduleThatListens.name);
            }
          }
        }

        if (module.writePort.connectsTo !== null) {
          const moduleThatReads = this.getModuleById(module.writePort.connectsTo, modules);
          if (moduleThatReads.type !== AgapiaModuleType.FOREACH) {
            if (!this.portsAreCompatible(module.writePort, moduleThatReads.readPort)) {
              messages.warnings.push(this.getModulePath(this.getModuleById(module.parentId, modules), modules) + ": incompatible write-read connection between modules " + module.name + " " + moduleThatReads.name);
            }
          }
        }
      }

      this.validateChildren(module, modules, messages);

    });

    return messages;
  }

  portsAreCompatible(port1: AgapiaModulePort, port2: AgapiaModulePort): boolean {
    if (port1.ports.length !== port2.ports.length) {
      return false;
    }

    for (let i = 0; i < port1.ports.length; i++) {
      if (port1.ports[i].variables.length !== port2.ports[i].variables.length) {
        return false;
      }
      for (let j = 0; j < port1.ports[i].variables.length; j++) {
        return port1.ports[i].variables[j].name === port2.ports[i].variables[j].name && port1.ports[i].variables[j].type === port2.ports[i].variables[j].type;
      }
    }

    return true;
  }

  private getModulePath(module: AgapiaModule, modules: Array<AgapiaModule>): string {
    if (module.name === "MAIN") return "MAIN";

    var path = module.name;

    var parentModule = this.getModuleById(module.parentId, modules);
    while (parentModule.parentId !== null) {
      path = parentModule.name + " -> " + path;
      parentModule = this.getModuleById(module.parentId, modules);
    }

    path = "MAIN" + " -> " + path;

    return path;
  }

  private getModuleById(id: number, modules: Array<AgapiaModule>): AgapiaModule {
    const index = modules.findIndex(module => module.id === id);
    if (index > -1) {
      return modules[index];
    }
    return null;
  }

  private validateChildren(module: AgapiaModule, modules: Array<AgapiaModule>, messages: ValidationMessages) {
    var children = modules.filter(m => m.parentId !== null && m.parentId === module.id);
    if (children.length !== 0) {
      var nrOfModulesThatDoNotReceive = 0;
      children.forEach(m => {
        if (m.listenPort.connectsTo === null && m.readPort.connectsTo === null) nrOfModulesThatDoNotReceive++;
      });
      if (nrOfModulesThatDoNotReceive > 1) messages.errors.push(this.getModulePath(this.getModuleById(module.id, modules), modules) + " contains unlinked modules");
    }
  }
}
