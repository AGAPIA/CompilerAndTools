import { ChangeDetectorRef, Component, ViewChild, ViewEncapsulation } from '@angular/core';
import * as go from 'gojs';
import { DataSyncService, DiagramComponent, PaletteComponent } from 'gojs-angular';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { AgapiaModule, AgapiaModuleType } from './models/agapia-module.model';
import { ExportService } from './service/export.service';
import { ImportService } from './service/import.service';
import { ModuleValidationService, ValidationMessages } from './service/module-validation.service';
import { ModuleService } from './service/module.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {

  @ViewChild('myDiagram', { static: true }) public myDiagramComponent: DiagramComponent;
  @ViewChild('myPalette', { static: true }) public myPaletteComponent: PaletteComponent;

  constructor(private cdr: ChangeDetectorRef,
    private exportService: ExportService,
    private importService: ImportService,
    private moduleService: ModuleService,
    private validationService: ModuleValidationService,
    private messageService: MessageService) { }

  idModuleDisplayed: number = 0;
  validationMessages: ValidationMessages = null;

  // currently selected node; for inspector
  public selectedNode: go.Node | null = null;

  public ngAfterViewInit() {

    if (this.observedDiagram) return;
    this.observedDiagram = this.myDiagramComponent.diagram;
    this.cdr.detectChanges(); // IMPORTANT: without this, Angular will throw ExpressionChangedAfterItHasBeenCheckedError (dev mode only)

    const appComp: AppComponent = this;

    this.myDiagramComponent.diagram.addDiagramListener('ChangedSelection', function (e) {
      if (e.diagram.selection.count === 0) {
        appComp.selectedNode = null;
      }
      const node = e.diagram.selection.first();
      if (node instanceof go.Node) {
        appComp.selectedNode = node;
      } else {
        appComp.selectedNode = null;
      }
    });
    this.myDiagramComponent.diagram.addDiagramListener('ObjectDoubleClicked', function (e) {
      if (e.diagram.selection.count !== 0) {
        const node = e.diagram.selection.first();
        if (node instanceof go.Node) {
          const selectedModule = appComp.moduleService.getModuleByDiagramNodeKeyAndParentModule(node.key, appComp.idModuleDisplayed);
          appComp.moveInsideModule(selectedModule);
        }
      }
    });
    this.myDiagramComponent.diagram.addDiagramListener('BackgroundDoubleClicked', function (e) {
      if (appComp.idModuleDisplayed !== 0) {
        const parentModuleId = appComp.moduleService.getModuleById(appComp.idModuleDisplayed).parentId;
        const parentModule = appComp.moduleService.getModuleById(parentModuleId);
        appComp.moveInsideModule(parentModule);
      }
    });
  }

  public moveInsideModule(agapiaModule: AgapiaModule) {
    const modulesToDisplay = this.moduleService.getAllModulesByParent(agapiaModule.id);

    var diagramNodeData = this.diagramNodeDataFromAgapiaModules(modulesToDisplay);
    var diagramLinkData = this.diagramLinkDataFromAgapiaModules(modulesToDisplay);

    this.skipsDiagramUpdate = false;

    //without reseting to empty and update only after a timeout value, the diagram seems to have problems redrawing when the modules have been imported
    this.diagramNodeData = [];
    this.diagramLinkData = [];
    setTimeout(() => {
      this.diagramNodeData = diagramNodeData;
      this.diagramLinkData = diagramLinkData;
    }, 500);

    this.idModuleDisplayed = agapiaModule.id;
  }

  diagramNodeDataFromAgapiaModules(agapiaModules: Array<AgapiaModule>): Array<go.ObjectData> {
    var diagramNodeData: Array<go.ObjectData> = [];
    agapiaModules.forEach(module => {
      var diagNode: go.ObjectData = {
        key: module.diagramNodeKey, name: module.name, color: module.color,
        read: this.moduleService.portTextFromAgapiaPorts(module.readPort.ports),
        listen: this.moduleService.portTextFromAgapiaPorts(module.listenPort.ports),
        speak: this.moduleService.portTextFromAgapiaPorts(module.speakPort.ports),
        write: this.moduleService.portTextFromAgapiaPorts(module.writePort.ports)
      };
      diagramNodeData.push(diagNode);
    });
    return diagramNodeData;
  }

  diagramLinkDataFromAgapiaModules(agapiaModules: Array<AgapiaModule>): Array<go.ObjectData> {
    var diagramLinkData: Array<go.ObjectData> = [];
    var linkKey: number = -1;
    agapiaModules.forEach(module => {
      if (module.speakPort.connectsTo !== null) {
        var linkData: go.ObjectData = {
          key: linkKey, from: module.diagramNodeKey, to: this.moduleService.getModuleById(module.speakPort.connectsTo).diagramNodeKey,
          fromPort: 'speak', toPort: 'listen'
        };
        diagramLinkData.push(linkData);
        linkKey--;
      }
      if (module.writePort.connectsTo !== null) {
        var linkData: go.ObjectData = {
          key: linkKey, from: module.diagramNodeKey, to: this.moduleService.getModuleById(module.writePort.connectsTo).diagramNodeKey,
          fromPort: 'write', toPort: 'read'
        };
        diagramLinkData.push(linkData);
        linkKey--;
      }
    });
    return diagramLinkData;
  }

  resetDiagramNodeKeys(agapiaModules: Array<AgapiaModule>) {
    var key: number = -1;
    agapiaModules.forEach(module => {
      module.diagramNodeKey = key;
      key--;
    });
  }

  updateModules(changes: go.IncrementalData): go.IncrementalData {
    console.log(changes);
    if (changes.insertedNodeKeys) {
      //add new module
      var newModule: AgapiaModule = new AgapiaModule();
      newModule.id = this.moduleService.getId();
      newModule.name = changes.modifiedNodeData[0].name;
      newModule.type = this.getModuleTypeFromNewNodeName(changes.modifiedNodeData[0].name);
      newModule.parentId = this.idModuleDisplayed;
      newModule.diagramNodeKey = changes.modifiedNodeData[0].key;
      newModule.color = changes.modifiedNodeData[0].color;
      this.moduleService.addModule(newModule);
    }
    else if (changes.removedNodeKeys) {
      //remove the module uniquely identified by the diagram key and parent module id (the module displayed in the diagram)
      this.moduleService.removeModuleByDiagramNodeKeyAndParentModule(changes.removedNodeKeys[0], this.idModuleDisplayed);
      //service also removes the connections, so there is not need to process changes.removedLinkKeys in this case
    }
    else if (changes.insertedLinkKeys) {
      //add connection
      var fromModule: AgapiaModule = this.moduleService.getModuleByDiagramNodeKeyAndParentModule(changes.modifiedLinkData[0].from, this.idModuleDisplayed);
      var toModule: AgapiaModule = this.moduleService.getModuleByDiagramNodeKeyAndParentModule(changes.modifiedLinkData[0].to, this.idModuleDisplayed);
      if (changes.modifiedLinkData[0].fromPort === 'speak' && changes.modifiedLinkData[0].toPort === 'listen') {
        this.moduleService.addConnectionSpeakListen(fromModule, toModule);
      }
      else if (changes.modifiedLinkData[0].fromPort === 'write' && changes.modifiedLinkData[0].toPort === 'read') {
        this.moduleService.addConnectionWriteRead(fromModule, toModule);
      }
      else {
        this.displayErrorMessage("Invalid port connection", "");
        //TODO: investigate a better a way to make erase link
        this.removeBadLinkByKeyAfterDelay(changes.insertedLinkKeys[0]);
      }
    }
    else if (changes.removedLinkKeys) {
      //remove connection
      const removedLink = this.diagramLinkData.filter(link => link.key === changes.removedLinkKeys[0])[0];
      var fromModule: AgapiaModule = this.moduleService.getModuleByDiagramNodeKeyAndParentModule(removedLink.from, this.idModuleDisplayed);
      var toModule: AgapiaModule = this.moduleService.getModuleByDiagramNodeKeyAndParentModule(removedLink.to, this.idModuleDisplayed);
      if (removedLink.fromPort === 'speak') {
        this.moduleService.removeConnectionSpeakListen(fromModule, toModule);
      }
      else if (removedLink.fromPort === 'write') {
        this.moduleService.removeConnectionWriteRead(fromModule, toModule);
      }
    }
    this.validationMessages = this.validationService.validate(this.moduleService.getAllModules());
    this.moduleService.updateParentModule(this.idModuleDisplayed);
    return changes;
  }

  removeBadLinkByKeyAfterDelay(linkKey) {
    setTimeout(() => {
      this.skipsDiagramUpdate = false;
      const index = this.diagramLinkData.indexOf(link => link.key === linkKey);
      this.diagramLinkData.splice(index, 1);
    }, 1000);
    this.skipsDiagramUpdate = true;
    this.validationMessages = this.validationService.validate(this.moduleService.getAllModules());
    this.moduleService.updateParentModule(this.idModuleDisplayed);
  }

  getModuleTypeFromNewNodeName(name: string): AgapiaModuleType {
    for (const type in AgapiaModuleType) {
      if (type === name) return AgapiaModuleType[type];
    }

    return AgapiaModuleType.USER_DEFINED;
  }

  displayErrorMessage(summary: string, detail: string) {
    this.messageService.add({ severity: 'error', summary: summary, detail: detail });
  }

  // -------------------- EXPORT -------------------

  onExport() {
    if (this.validationMessages.errors.length === 0) {
      const modules = this.moduleService.getAllModules();
      // console.log(modules);

      //call service to export and download txt
      this.exportService.exportToAgapiaTxt(modules).subscribe(response => {
        let blob = new Blob([response.body], { type: 'text/plain; charset=utf-8' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'agapia.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      },
        (error => {
          this.displayErrorMessage("Error encountered while exporting", "");
          console.log(error);
        })
      );
    }
    else {
      this.displayErrorMessage("Error", "Cannot export before fixing errors");
    }
  }


  // ---------------------------- IMPORT ----------------------------------

  onUpload(event) {
    this.importService.importAgapiaTxt(event.files[0]).subscribe(
      (moduleList: Array<AgapiaModule>) => {
        this.moduleService.resetModuleList(moduleList);
        // console.log(moduleList);
        this.moveInsideModule(this.moduleService.getModuleById(0));
        this.validationMessages = this.validationService.validate(this.moduleService.getAllModules());
        this.moduleService.getAllModules().forEach(module => this.moduleService.updateParentModule(module.id));
      },
      (error) => {
        this.displayErrorMessage("Error encountered while importing", "");
        console.log(error);
      }
    );
  }


  // ---------- DIAGRAM DEFINITION AND INITIALIZATION HERE ------------------------------

  // initialize diagram / templates

  public diagramNodeData: Array<go.ObjectData> = [];
  public diagramLinkData: Array<go.ObjectData> = [];

  public initDiagram(): go.Diagram {

    const $ = go.GraphObject.make;

    const makePort = function (id: string, spot: go.Spot, isInput: boolean, isOutput: boolean) {
      return $(go.Shape, 'Rectangle',
        {
          opacity: .5,
          fill: 'black', strokeWidth: 0, desiredSize: new go.Size(8, 8),
          portId: id, alignment: spot,
          fromLinkable: isOutput, toLinkable: isInput,
          toMaxLinks: 1, fromMaxLinks: 1
        }
      );
    }

    const dia = $(go.Diagram, {
      'undoManager.isEnabled': true,
      model: $(go.GraphLinksModel,
        {
          linkToPortIdProperty: 'toPort',
          linkFromPortIdProperty: 'fromPort',
          linkKeyProperty: 'key' // IMPORTANT! must be defined for merges and data sync when using GraphLinksModel
        }
      )
    });

    dia.linkTemplate =
      $(go.Link,
        { routing: go.Link.Orthogonal, corner: 3 },
        $(go.Shape),
        $(go.Shape, { toArrow: "Standard" })
      );

    dia.initialContentAlignment = go.Spot.TopLeft;
    dia.layout = $(go.LayeredDigraphLayout, { columnSpacing: 50, layerSpacing: 50, setsPortSpots: false });

    dia.commandHandler.archetypeGroupData = { key: 'Group', isGroup: true };

    // define the Node template
    dia.nodeTemplate =
      $(go.Node, 'Auto',
        {
          contextMenu:
            $('ContextMenu',
              $('ContextMenuButton',
                $(go.TextBlock, 'Group'),
                { click: function (e, obj) { e.diagram.commandHandler.groupSelection(); } },
                new go.Binding('visible', '', function (o) {
                  return o.diagram.selection.count > 1;
                }).ofObject())
            )
        },
        $(go.Shape, 'RoundedRectangle', { stroke: "lightgray" },
          new go.Binding('fill', 'color')
        ),
        $(go.Panel, 'Table',
          { desiredSize: new go.Size(250, 250) },
          //MODULE NAME
          $(go.TextBlock,
            { alignment: go.Spot.Top, font: "bold 10pt sans-serif", margin: new go.Margin(70) },
            new go.Binding('text', 'name')),
          //PORTS TEXT
          $(go.TextBlock,
            {
              alignment: go.Spot.TopCenter, font: "10pt sans-serif", margin: new go.Margin(10),
              width: 230, height: 50, textAlign: 'center', maxLines: 3, overflow: go.TextBlock.OverflowEllipsis
            },
            new go.Binding('text', 'read')),
          $(go.TextBlock,
            {
              alignment: go.Spot.Left, font: "10pt sans-serif", margin: new go.Margin(0, 0, 0, 10),
              width: 90, height: 50, textAlign: 'start', verticalAlignment: go.Spot.Center, maxLines: 5, overflow: go.TextBlock.OverflowEllipsis
            },
            new go.Binding('text', 'listen')),
          $(go.TextBlock,
            {
              alignment: go.Spot.Right, font: "10pt sans-serif", margin: new go.Margin(0, 10),
              width: 90, height: 50, textAlign: 'end', verticalAlignment: go.Spot.Center, maxLines: 5, overflow: go.TextBlock.OverflowEllipsis
            },
            new go.Binding('text', 'speak')),
          $(go.TextBlock,
            {
              alignment: go.Spot.BottomCenter, font: "10pt sans-serif", margin: new go.Margin(0, 0, 10, 0),
              width: 230, height: 50, textAlign: 'center', verticalAlignment: go.Spot.Bottom, maxLines: 3, overflow: go.TextBlock.OverflowEllipsis
            },
            new go.Binding('text', 'write'))
        ),
        // Ports
        makePort('read', go.Spot.TopCenter, true, false),
        makePort('listen', go.Spot.Left, true, false),
        makePort('speak', go.Spot.Right, false, true),
        makePort('write', go.Spot.BottomCenter, false, true)
      );

    return dia;
  }

  public diagramDivClassName: string = 'myDiagramDiv';
  public diagramModelData = { prop: 'value' };
  public skipsDiagramUpdate = false;

  // When the diagram model changes, update app data to reflect those changes
  public diagramModelChange = function (changes: go.IncrementalData) {
    // when setting state here, be sure to set skipsDiagramUpdate: true since GoJS already has this update
    // (since this is a GoJS model changed listener event function)
    // this way, we don't log an unneeded transaction in the Diagram's undoManager history
    this.skipsDiagramUpdate = true;

    if (changes) changes = this.updateModules(changes);

    this.diagramNodeData = DataSyncService.syncNodeData(changes, this.diagramNodeData);
    this.diagramLinkData = DataSyncService.syncLinkData(changes, this.diagramLinkData);
    this.diagramModelData = DataSyncService.syncModelData(changes, this.diagramModelData);
  };


  // ---------- PALETTE DEFINITION AND INITIALIZATION ------------------------------

  public paletteNodeData: Array<go.ObjectData> = [
    { name: 'CUSTOM_MODULE', color: 'Moccasin', read: 'nil', listen: 'nil', speak: 'nil', write: 'nil' },
    { name: 'PARENTHESIS', color: 'Orange', read: 'nil', listen: 'nil', speak: 'nil', write: 'nil' },
    { name: 'FOREACH', color: 'IndianRed', read: 'nil', listen: 'nil', speak: 'nil', write: 'nil' }
  ];

  public initPalette(): go.Palette {
    const $ = go.GraphObject.make;
    const palette = $(go.Palette);

    const makePort = function (id: string, spot: go.Spot, isInput: boolean, isOutput: boolean) {
      return $(go.Shape, 'Rectangle',
        {
          opacity: .5,
          fill: 'black', strokeWidth: 0, desiredSize: new go.Size(8, 8),
          portId: id, alignment: spot,
          fromLinkable: isOutput, toLinkable: isInput,
          toMaxLinks: 1, fromMaxLinks: 1
        }
      );
    }

    // define the Node template
    palette.nodeTemplate =
      $(go.Node, 'Auto',
        {
          contextMenu:
            $('ContextMenu',
              $('ContextMenuButton',
                $(go.TextBlock, 'Group'),
                { click: function (e, obj) { e.diagram.commandHandler.groupSelection(); } },
                new go.Binding('visible', '', function (o) {
                  return o.diagram.selection.count > 1;
                }).ofObject())
            )
        },
        $(go.Shape, 'RoundedRectangle', { stroke: "lightgray" },
          new go.Binding('fill', 'color')
        ),
        $(go.Panel, 'Table',
          { desiredSize: new go.Size(200, 50) },
          //MODULE NAME
          $(go.TextBlock,
            { alignment: go.Spot.Top, font: "bold 10pt sans-serif", margin: new go.Margin(15) },
            new go.Binding('text', 'name')),
        ),
        // Ports
        makePort('read', go.Spot.TopCenter, true, false),
        makePort('listen', go.Spot.Left, true, false),
        makePort('speak', go.Spot.Right, false, true),
        makePort('write', go.Spot.BottomCenter, false, true)
      );

    palette.model = $(go.GraphLinksModel,
      {
        linkKeyProperty: 'key'  // IMPORTANT! must be defined for merges and data sync when using GraphLinksModel
      });

    return palette;
  }

  public paletteLinkData: Array<go.ObjectData> = [];
  public paletteModelData = { prop: 'val' };
  public paletteDivClassName = 'myPaletteDiv';
  public skipsPaletteUpdate = false;
  public paletteModelChange = function (changes: go.IncrementalData) {
    // when setting state here, be sure to set skipsPaletteUpdate: true since GoJS already has this update
    // (since this is a GoJS model changed listener event function)
    // this way, we don't log an unneeded transaction in the Palette's undoManager history
    this.skipsPaletteUpdate = true;

    this.paletteNodeData = DataSyncService.syncNodeData(changes, this.paletteNodeData);
    this.paletteLinkData = DataSyncService.syncLinkData(changes, this.paletteLinkData);
    this.paletteModelData = DataSyncService.syncModelData(changes, this.paletteModelData);
  };



  // ---------- OVERVIEW DEFINITION AND INITIALIZATION ------------------------------

  public oDivClassName = 'myOverviewDiv';
  public initOverview(): go.Overview {
    const $ = go.GraphObject.make;
    const overview = $(go.Overview);
    return overview;
  }
  public observedDiagram = null;


  // ---------- INSPECTOR CHANGE ------------------------------


  public handleInspectorChange(newNodeData) {
    const key = newNodeData.key;
    // find the entry in nodeDataArray with this key, replace it with newNodeData
    let index = null;
    for (let i = 0; i < this.diagramNodeData.length; i++) {
      const entry = this.diagramNodeData[i];
      if (entry.key && entry.key === key) {
        index = i;
      }
    }

    if (index >= 0) {
      // here, we set skipsDiagramUpdate to false, since GoJS does not yet have this update
      this.skipsDiagramUpdate = false;
      this.diagramNodeData[index] = _.cloneDeep(newNodeData);
      this.validationMessages = this.validationService.validate(this.moduleService.getAllModules());
    }
  }

}

